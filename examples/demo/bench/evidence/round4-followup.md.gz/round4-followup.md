# next-scriptc benchmark

**INDICATIVE ONLY: developer machine / reduced repetitions; not publishable performance evidence**

Status: complete. Commit: 0ca22f537d11df1f4594b7cac6d73ce05b36cd89. Node v24.22.0; scriptc 0.4.6; Next 16.4.3.

Apple M4 Pro; 12 logical CPUs; darwin/arm64; load averages start 15.73876953125, 11.5302734375, 8.3681640625, end 20.99853515625, 15.66455078125, 10.64697265625.

Started 2026-10-31T02:36:34.559Z; ended 2026-10-31T02:39:30.850Z. Profile: quick. Affinity: {}.

Full environment, build IDs, source/binary hashes, dirty status, raw repetitions, per-process snapshots, requests, and workload configuration are in the adjacent JSON. Brackets below are [min, max] across repeated runs, not confidence intervals.


## Final production summary — wins and losses together

Every HTTP workload appears below. Values are medians of measured end-to-end rows, followed by variant/Node ratios; 1× is parity. Each column states its ratio direction. Passwords have no C=64 measurement. Asterisk means suspected generator saturation in the variant or Node baseline (throughput is then a lower bound on capacity). No direct measurement fills a production cell. Missing, refused and failed cells stay explicit.

| Workload | Configuration | C=1 p50 ms; ratio to Node (lower is better) | C=64 req/s; ratio to Node (higher is better) | CPU ms/request; ratio to Node (lower is better) | Cold ms; ratio to Node (lower is better) |
| --- | --- | --- | --- | --- | --- |
| login | node | 86.701; 1.000× | unmeasured (bounded C=1) | 86.667; 1.000× | not measured (section absent/incomplete) |
| login | native | 6826.279; 78.733× | unmeasured (bounded C=1) | 6813.333; 78.615× | not measured (section absent/incomplete) |
| login | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| login-scrypt | node | 65.762; 1.000× | unmeasured (bounded C=1) | 66.667; 1.000× | not measured (section absent/incomplete) |
| login-scrypt | native | 70.680; 1.075× | unmeasured (bounded C=1) | 73.333; 1.100× | not measured (section absent/incomplete) |
| login-scrypt | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| verify | node | 0.326; 1.000× | 5508.911; 1.000× | 0.500; 1.000× | not measured (section absent/incomplete) |
| verify | native | 0.204; 0.626× | 12911.029; 2.344× | 0.500; 1.000× | not measured (section absent/incomplete) |
| verify | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| search | node | 0.892; 1.000× | 1585.100; 1.000× | 1.000; 1.000× | not measured (section absent/incomplete) |
| search | native | 3.169; 3.555× | 452.526; 0.285× | 3.250; 3.250× | not measured (section absent/incomplete) |
| search | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| markdown | node | 0.653; 1.000× | 2132.442; 1.000× | 0.750; 1.000× | not measured (section absent/incomplete) |
| markdown | native | 18.589; 28.471× | 53.561; 0.025× | 19.000; 25.333× | not measured (section absent/incomplete) |
| markdown | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| feed | node | 0.806; 1.000× | 1596.242; 1.000× | 0.750; 1.000× | not measured (section absent/incomplete) |
| feed | native | 23.493; 29.151× | 44.049; 0.028× | 23.000; 30.667× | not measured (section absent/incomplete) |
| feed | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| upload-integrity | node | 1.297; 1.000× | 784.793; 1.000× | 3.750; 1.000× | not measured (section absent/incomplete) |
| upload-integrity | native | 4.971; 3.833× | 229.239; 0.292× | 6.750; 1.800× | not measured (section absent/incomplete) |
| upload-integrity | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| gzip-export | node | 3.349; 1.000× | 403.514; 1.000× | 4.000; 1.000× | not measured (section absent/incomplete) |
| gzip-export | native | 2.269; 0.678× | 655.511; 1.625× | 1.750; 0.438× | not measured (section absent/incomplete) |
| gzip-export | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| revenue | node | 2.507; 1.000× | 478.323; 1.000× | 2.750; 1.000× | not measured (section absent/incomplete) |
| revenue | native | 1.013; 0.404× | 1389.105; 2.904× | 1.000; 0.364× | not measured (section absent/incomplete) |
| revenue | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| image-histogram | node | 1.357; 1.000× | 777.090; 1.000× | 4.000; 1.000× | not measured (section absent/incomplete) |
| image-histogram | native | 1.892; 1.394× | 774.145; 0.996× | 4.250; 1.063× | not measured (section absent/incomplete) |
| image-histogram | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| nearby-stores | node | 1.440; 1.000× | 1012.015; 1.000× | 1.000; 1.000× | not measured (section absent/incomplete) |
| nearby-stores | native | 1.242; 0.862× | 1112.140; 1.099× | 1.000; 1.000× | not measured (section absent/incomplete) |
| nearby-stores | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| hello | node | 0.217; 1.000× | 7309.114; 1.000× | 0.500; 1.000× | not measured (section absent/incomplete) |
| hello | native | 0.141; 0.649× | 13963.934; 1.910× | 0.250; 0.500× | not measured (section absent/incomplete) |
| hello | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| primes | node | 3.806; 1.000× | 322.320; 1.000× | 4.250; 1.000× | not measured (section absent/incomplete) |
| primes | native | 3.776; 0.992× | 309.204; 0.959× | 3.500; 0.824× | not measured (section absent/incomplete) |
| primes | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| csv | node | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists |
| csv | native | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists |
| csv | native-grouped | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists |

Whole-app summed RSS includes Next, supervisor and every resident native process. Idle follows hello readiness. Loaded is the maximum simultaneous sampled RSS across all production CPU/throughput rows in the fixed workload order, including allocator/GC history; it is not PSS or a kernel peak. Both ratios below are variant/Node, **lower is better**.

| Configuration | Idle MiB; ratio to Node (lower is better) | Loaded MiB; ratio to Node (lower is better) | Status |
| --- | --- | --- | --- |
| node | 119.094; 1.000× | 836.094; 1.000× | measured |
| native | 198.984; 1.671× | 1147.984; 1.373× | measured |
| native-grouped | not measured | not measured | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |

Sections completed: coverage, production, isolation, threads. Omitted sections are absent, not zero. Native-grouped is production-only; direct and internal-worker rows remain Node/native.


## Limitations alongside the results

- Headline application workloads are successful cost-10 bcrypt login, async scrypt login (N=32768, r=8, p=1), authenticated JWT verification, 3,000-product search, uncached Markdown rendering, RSS, 1 MiB upload integrity, gzip export, revenue aggregation, raw RGBA histogram and nearby-store search. hello is a small-response control; primes and report are synthetic. These fixtures have no database or remote I/O.
- Native bcrypt is a known regression: the earlier correctness probe took 26.8 s for three cost-10 operations versus 0.56 s on Node (~48× slower). Login therefore measures only three requests, C=1, one measured repetition and one separate cold request per surface. Its p99 is simply the maximum of three, not credible tail evidence. No reduced cost, invalid password or 401 shortcut is substituted. CSV and OG-image generation were refused by the probe; see examples/probe/RESULTS.md.
- If a route exceeds Next’s default 30-second upstream proxy timeout, production returns HTTP 500. The suite records that workload as exceeding the default 30 s proxy timeout when elapsed time and upstream-reset logs confirm it, preserves server logs, sets dataset status failed/nonzero exit and continues independent workloads. It never increases the production timeout, substitutes a faster error path or counts failed responses as throughput.
- Coverage static percentage is not a typed-machine-code percentage: scriptc includes dynamic-tier statements in its compile-statically total. Dynamic counts and package modes are displayed alongside speed; package mode static does not exclude untyped JS operations. Coverage describes the entry graph, not measured hot-path time, so it suggests explanations without proving causality.
- Node baseline is a production next build / next start with adapter disabled (.next-node), normal V8 JIT, no debug or memory flags. Direct Node uses the identical generated entry and HTTP shim, without a Next server. Native end-to-end includes the extra Next proxy and all resident route processes. Native-grouped uses the registered eight-route light group; it shares scheduling, state and failure fate, and gzip isolation measures contention inside that group.
- hello reads Accept-Language and feed reads a result limit from request.url: with cacheComponents these are dynamic, and both sides compute every measured response. Node prerendered paths are recorded separately; no Next optimization is disabled. Async scrypt uses Node's default libuv threadpool; scriptc 0.4.6 computes the derivation before deferring the callback. Isolation includes both async scrypt and synchronous bcrypt, so a bcrypt isolation win does not describe production-style async password hashing.
- Linux uses two allowed CPUs for the application tree and two disjoint CPUs for generator + controller. Both runtimes inherit the same masks. Threads alone use all four CPUs for 1/2/4-worker scaling; they have no sustained HTTP load generator. These are logical CPUs; topology/SMT and other sandbox tenants may still affect results. macOS cannot use taskset: local output is indicative only.
- Run order: cold runtimes alternate. Default steady blocks are direct Node, direct native, end-to-end Node, end-to-end native, end-to-end native-grouped; --reverse reverses runtime order and is recorded in the profile. All repeated steady runs share their block's process/JIT/cache/allocator state. No multiple application modes run together. Repeat on a quiet host in both orders before publishing close comparisons.
- Client and server share a machine and memory bandwidth. The single Node generator can bottleneck on one JS thread even with a two-CPU affinity mask. Rows flag suspected generator saturation at >=0.8 CPU-seconds per wall-second; flagged throughput is a lower bound on server capacity. CPU pinning reduces CPU contention but does not eliminate shared-resource interference. No load-generator ceiling calibration is implied.
- SAB is a standalone Node program to expose the strongest Node sharing baseline without adding an application route. Its internal timed region matches report, and every total must match. It has no idle HTTP shim; RSS is therefore slightly favorable to SAB. SAB and object layouts/code accesses differ by necessity. This tests sharing ergonomics + overhead, not identical-code compiler speed. Dataset construction and worker initialization costs are excluded from time. Warmed total RSS retains the dataset and resident pool; the marginal metric compares warmed 1/4-worker states within a process.
- Idle and after-load memory are runtime/GC-state dependent. Peak sampling can miss spikes; summed RSS overcounts shared pages. CPU ticks can make tiny-request per-request CPU noisy: increase fixed count for public claims. Active CPU here is OS user+system process CPU, not a reproduction of Vercel billing instrumentation.
- Responses are checked for expected status and byte-for-byte SHA-256 parity before timing and throughout load. Gzip export checks decoded bytes and representation headers, allowing valid compressed encodings to differ; client decompression CPU is separate, while latency includes it on both runtimes. Workloads must use deterministic fixtures, including a fixed clock/key for token issuance. No TLS, remote network, serverless scheduling, multi-instance autoscaling or platform cold starts are measured.


## Workload fixtures

Node build prerendered paths: /, /_global-error, /_not-found, /api/items/new, /api/static-fixture, /favicon.ico.

| Route | Kind | Request / pending |
| --- | --- | --- |
| login | realistic | POST /api/login |
| login-scrypt | realistic | POST /api/login-scrypt |
| verify | realistic | GET /api/verify |
| search | realistic | GET /api/search?q=desk%20lamp&limit=7 |
| markdown | realistic | GET /api/posts/reliable-webhooks |
| feed | realistic | GET /api/feed.xml |
| upload-integrity | realistic | POST /api/uploads/verify |
| gzip-export | realistic | GET /api/export.json.gz?rows=5000 |
| revenue | realistic | GET /api/analytics/revenue?from=2026-01-01&to=2026-01-31 |
| image-histogram | realistic | POST /api/images/histogram?width=512&height=512 |
| nearby-stores | realistic | GET /api/stores/nearby?lat=51.5074&lng=-0.1278&radiusKm=1000 |
| hello | control | GET /api/hello |
| primes | synthetic | GET /api/primes?limit=1000000 |
| csv | refused | DISABLED: Papa Parse unparse refused in route probe; no CSV route exists |

## Application workloads, C=1 (latency and single-route coverage together)

| Route | Scope | Node p50 ms | Native p50 ms | Native / Node latency (lower is better) | Native-grouped p50 ms | Grouped / Node latency (lower is better) | Statements / static % / dynamic tier | Package modes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| login | direct | — | — | — | production only | — | 2170 / 99% / 437 | bcryptjs: static; jose: static |
| login | end-to-end | 86.701 | 6826.279 | 78.733× | SKIPPED (build absent) | — | 2170 / 99% / 437 | bcryptjs: static; jose: static |
| login-scrypt | direct | — | — | — | production only | — | 1756 / 99% / 238 | jose: static |
| login-scrypt | end-to-end | 65.762 | 70.680 | 1.075× | SKIPPED (build absent) | — | 1756 / 99% / 238 | jose: static |
| verify | direct | — | — | — | production only | — | 1784 / 99% / 252 | jose: static |
| verify | end-to-end | 0.326 | 0.204 | 0.626× | SKIPPED (build absent) | — | 1784 / 99% / 252 | jose: static |
| search | direct | — | — | — | production only | — | 1109 / 100% / 355 | minisearch: static |
| search | end-to-end | 0.892 | 3.169 | 3.555× | SKIPPED (build absent) | — | 1109 / 100% / 355 | minisearch: static |
| markdown | direct | — | — | — | production only | — | 1301 / 100% / 652 | marked: static |
| markdown | end-to-end | 0.653 | 18.589 | 28.471× | SKIPPED (build absent) | — | 1301 / 100% / 652 | marked: static |
| feed | direct | — | — | — | production only | — | 1305 / 100% / 653 | marked: static |
| feed | end-to-end | 0.806 | 23.493 | 29.151× | SKIPPED (build absent) | — | 1305 / 100% / 653 | marked: static |
| upload-integrity | direct | — | — | — | production only | — | 410 / 100% / 38 | none |
| upload-integrity | end-to-end | 1.297 | 4.971 | 3.833× | SKIPPED (build absent) | — | 410 / 100% / 38 | none |
| gzip-export | direct | — | — | — | production only | — | 409 / 100% / 37 | none |
| gzip-export | end-to-end | 3.349 | 2.269 | 0.678× | SKIPPED (build absent) | — | 409 / 100% / 37 | none |
| revenue | direct | — | — | — | production only | — | 435 / 100% / 37 | none |
| revenue | end-to-end | 2.507 | 1.013 | 0.404× | SKIPPED (build absent) | — | 435 / 100% / 37 | none |
| image-histogram | direct | — | — | — | production only | — | 421 / 100% / 41 | none |
| image-histogram | end-to-end | 1.357 | 1.892 | 1.394× | SKIPPED (build absent) | — | 421 / 100% / 41 | none |
| nearby-stores | direct | — | — | — | production only | — | 424 / 100% / 39 | none |
| nearby-stores | end-to-end | 1.440 | 1.242 | 0.862× | SKIPPED (build absent) | — | 424 / 100% / 39 | none |

## Coverage of every measured entry (controls and synthetic included)

| Entry | Statements | Static statements / % | Dynamic tier statements | Package modes |
| --- | --- | --- | --- | --- |
| login | 2170 | 2159 / 99% | 437 | bcryptjs: static; jose: static |
| login-scrypt | 1756 | 1745 / 99% | 238 | jose: static |
| verify | 1784 | 1773 / 99% | 252 | jose: static |
| search | 1109 | 1109 / 100% | 355 | minisearch: static |
| markdown | 1301 | 1301 / 100% | 652 | marked: static |
| feed | 1305 | 1305 / 100% | 653 | marked: static |
| upload-integrity | 410 | 410 / 100% | 38 | none |
| gzip-export | 409 | 409 / 100% | 37 | none |
| revenue | 435 | 435 / 100% | 37 | none |
| image-histogram | 421 | 421 / 100% | 41 | none |
| nearby-stores | 424 | 424 / 100% | 39 | none |
| hello | 404 | 404 / 100% | 35 | none |
| primes | 418 | 418 / 100% | 36 | none |
| report | 490 | 490 / 100% | 44 | none |

## Cold start (ms, process-cold)

| Scope / runtime / route | N | Median | p90 | Min | Max |
| --- | --- | --- | --- | --- | --- |


## Idle RSS (MiB, per process and simultaneous total)

| Scope / runtime | Initialized by | PID / role | RSS MiB |
| --- | --- | --- | --- |
| end-to-end / node | hello | 29447 / next-server | 119.094 |
| end-to-end / node | hello | TOTAL | 119.094 |
| end-to-end / native | hello | 32850 / next-server | 119.688 |
| end-to-end / native | hello | 32851 / native-route | 3.875 |
| end-to-end / native | hello | 32852 / native-route | 3.375 |
| end-to-end / native | hello | 32853 / native-route | 6.047 |
| end-to-end / native | hello | 32854 / native-route | 3.109 |
| end-to-end / native | hello | 32855 / native-route | 2.594 |
| end-to-end / native | hello | 32856 / native-route | 2.594 |
| end-to-end / native | hello | 32857 / native-route | 3.734 |
| end-to-end / native | hello | 32858 / native-route | 3.609 |
| end-to-end / native | hello | 32859 / native-route | 6.078 |
| end-to-end / native | hello | 32860 / native-route | 2.594 |
| end-to-end / native | hello | 32861 / native-route | 2.703 |
| end-to-end / native | hello | 32862 / native-route | 25.844 |
| end-to-end / native | hello | 32863 / native-route | 4.406 |
| end-to-end / native | hello | 32864 / native-route | 2.609 |
| end-to-end / native | hello | 32865 / native-route | 2.594 |
| end-to-end / native | hello | 32866 / native-route | 3.531 |
| end-to-end / native | hello | TOTAL | 198.984 |

## Fixed-count process CPU and memory

| Scope / runtime / route | N per run | CPU ms/request median [min,max] | After N total RSS MiB | Sampled peak total MiB |
| --- | --- | --- | --- | --- |
| end-to-end / node / login | 3 | 86.667 [86.667, 86.667] | 123.125 [123.125, 123.125] | 123.125 [123.125, 123.125] |
| end-to-end / node / login-scrypt | 3 | 66.667 [66.667, 66.667] | 157.875 [157.875, 157.875] | 157.875 [157.875, 157.875] |
| end-to-end / node / verify | 40 | 0.500 [0.500, 0.500] | 190.844 [190.844, 190.844] | 190.844 [190.844, 190.844] |
| end-to-end / node / search | 40 | 1.000 [1.000, 1.000] | 436.297 [436.297, 436.297] | 436.297 [436.297, 436.297] |
| end-to-end / node / markdown | 40 | 0.750 [0.750, 0.750] | 451.375 [451.375, 451.375] | 451.375 [451.375, 451.375] |
| end-to-end / node / feed | 40 | 0.750 [0.750, 0.750] | 471.031 [471.031, 471.031] | 471.031 [471.031, 471.031] |
| end-to-end / node / upload-integrity | 40 | 3.750 [3.750, 3.750] | 577.297 [577.297, 577.297] | 577.297 [577.297, 577.297] |
| end-to-end / node / gzip-export | 40 | 4.000 [4.000, 4.000] | 757.922 [757.922, 757.922] | 758.641 [758.641, 758.641] |
| end-to-end / node / revenue | 40 | 2.750 [2.750, 2.750] | 760.984 [760.984, 760.984] | 760.984 [760.984, 760.984] |
| end-to-end / node / image-histogram | 40 | 4.000 [4.000, 4.000] | 762.078 [762.078, 762.078] | 762.078 [762.078, 762.078] |
| end-to-end / node / nearby-stores | 40 | 1.000 [1.000, 1.000] | 811.891 [811.891, 811.891] | 811.891 [811.891, 811.891] |
| end-to-end / node / hello | 40 | 0.500 [0.500, 0.500] | 803.250 [803.250, 803.250] | 803.250 [803.250, 803.250] |
| end-to-end / node / primes | 40 | 4.250 [4.250, 4.250] | 835.906 [835.906, 835.906] | 835.906 [835.906, 835.906] |
| end-to-end / native / login | 3 | 6813.333 [6813.333, 6813.333] | 201.547 [201.547, 201.547] | 201.547 [201.547, 201.547] |
| end-to-end / native / login-scrypt | 3 | 73.333 [73.333, 73.333] | 235.938 [235.938, 235.938] | 235.938 [235.938, 235.938] |
| end-to-end / native / verify | 40 | 0.500 [0.500, 0.500] | 290.766 [290.766, 290.766] | 290.766 [290.766, 290.766] |
| end-to-end / native / search | 40 | 3.250 [3.250, 3.250] | 457.922 [457.922, 457.922] | 457.922 [457.922, 457.922] |
| end-to-end / native / markdown | 40 | 19.000 [19.000, 19.000] | 464.078 [464.078, 464.078] | 464.078 [464.078, 464.078] |
| end-to-end / native / feed | 40 | 23.000 [23.000, 23.000] | 474.484 [474.484, 474.484] | 474.484 [474.484, 474.484] |
| end-to-end / native / upload-integrity | 40 | 6.750 [6.750, 6.750] | 513.219 [513.219, 513.219] | 513.219 [513.219, 513.219] |
| end-to-end / native / gzip-export | 40 | 1.750 [1.750, 1.750] | 801.625 [801.625, 801.625] | 801.625 [801.625, 801.625] |
| end-to-end / native / revenue | 40 | 1.000 [1.000, 1.000] | 819.266 [819.266, 819.266] | 819.266 [819.266, 819.266] |
| end-to-end / native / image-histogram | 40 | 4.250 [4.250, 4.250] | 856.734 [856.734, 856.734] | 856.734 [856.734, 856.734] |
| end-to-end / native / nearby-stores | 40 | 1.000 [1.000, 1.000] | 1108.203 [1108.203, 1108.203] | 1108.203 [1108.203, 1108.203] |
| end-to-end / native / hello | 40 | 0.250 [0.250, 0.250] | 1084.406 [1084.406, 1084.406] | 1084.406 [1084.406, 1084.406] |
| end-to-end / native / primes | 40 | 3.500 [3.500, 3.500] | 1146.891 [1146.891, 1146.891] | 1146.891 [1146.891, 1146.891] |

## Throughput / latency

| Scope / runtime / route / C | req/s median [min,max] | p50 ms median [min,max] | p99 ms median [min,max] | Peak total MiB | Measured sockets created / requests reused (each run) | Generator CPU cores / saturation suspected |
| --- | --- | --- | --- | --- | --- | --- |
| end-to-end / node / login / 1 | 11.515 [11.515, 11.515] | 86.701 [86.701, 86.701] | 87.103 [87.103, 87.103] | 123.125 [123.125, 123.125] | 0 / 3 of 3 | 0.011 [0.011, 0.011] / no |
| end-to-end / node / login-scrypt / 1 | 15.205 [15.205, 15.205] | 65.762 [65.762, 65.762] | 66.558 [66.558, 66.558] | 157.875 [157.875, 157.875] | 0 / 3 of 3 | 0.016 [0.016, 0.016] / no |
| end-to-end / node / verify / 1 | 2724.903 [2724.903, 2724.903] | 0.326 [0.326, 0.326] | 0.663 [0.663, 0.663] | 338.547 [338.547, 338.547] | 0 / 1090 of 1090 | 0.294 [0.294, 0.294] / no |
| end-to-end / node / verify / 8 | 5206.299 [5206.299, 5206.299] | 1.260 [1.260, 1.260] | 5.441 [5.441, 5.441] | 367.781 [367.781, 367.781] | 0 / 2088 of 2088 | 0.378 [0.378, 0.378] / no |
| end-to-end / node / verify / 64 | 5508.911 [5508.911, 5508.911] | 9.980 [9.980, 9.980] | 27.154 [27.154, 27.154] | 433.125 [433.125, 433.125] | 0 / 2244 of 2244 | 0.373 [0.373, 0.373] / no |
| end-to-end / node / search / 1 | 1039.478 [1039.478, 1039.478] | 0.892 [0.892, 0.892] | 1.622 [1.622, 1.622] | 437.844 [437.844, 437.844] | 0 / 416 of 416 | 0.217 [0.217, 0.217] / no |
| end-to-end / node / search / 8 | 1573.288 [1573.288, 1573.288] | 4.561 [4.561, 4.561] | 10.119 [10.119, 10.119] | 438.438 [438.438, 438.438] | 0 / 636 of 636 | 0.231 [0.231, 0.231] / no |
| end-to-end / node / search / 64 | 1585.100 [1585.100, 1585.100] | 38.856 [38.856, 38.856] | 76.774 [76.774, 76.774] | 447.266 [447.266, 447.266] | 0 / 700 of 700 | 0.185 [0.185, 0.185] / no |
| end-to-end / node / markdown / 1 | 1380.357 [1380.357, 1380.357] | 0.653 [0.653, 0.653] | 1.351 [1.351, 1.351] | 464.969 [464.969, 464.969] | 0 / 553 of 553 | 0.254 [0.254, 0.254] / no |
| end-to-end / node / markdown / 8 | 2078.946 [2078.946, 2078.946] | 3.163 [3.163, 3.163] | 7.867 [7.867, 7.867] | 468.359 [468.359, 468.359] | 0 / 838 of 838 | 0.271 [0.271, 0.271] / no |
| end-to-end / node / markdown / 64 | 2132.442 [2132.442, 2132.442] | 29.072 [29.072, 29.072] | 57.644 [57.644, 57.644] | 468.891 [468.891, 468.891] | 0 / 919 of 919 | 0.245 [0.245, 0.245] / no |
| end-to-end / node / feed / 1 | 1142.246 [1142.246, 1142.246] | 0.806 [0.806, 0.806] | 1.469 [1.469, 1.469] | 471.031 [471.031, 471.031] | 0 / 457 of 457 | 0.255 [0.255, 0.255] / no |
| end-to-end / node / feed / 8 | 1631.619 [1631.619, 1631.619] | 4.139 [4.139, 4.139] | 9.744 [9.744, 9.744] | 471.281 [471.281, 471.281] | 0 / 660 of 660 | 0.270 [0.270, 0.270] / no |
| end-to-end / node / feed / 64 | 1596.242 [1596.242, 1596.242] | 38.578 [38.578, 38.578] | 76.245 [76.245, 76.245] | 481.219 [481.219, 481.219] | 0 / 710 of 710 | 0.225 [0.225, 0.225] / no |
| end-to-end / node / upload-integrity / 1 | 670.485 [670.485, 670.485] | 1.297 [1.297, 1.297] | 3.053 [3.053, 3.053] | 596.422 [596.422, 596.422] | 0 / 269 of 269 | 0.278 [0.278, 0.278] / no |
| end-to-end / node / upload-integrity / 8 | 822.654 [822.654, 822.654] | 8.773 [8.773, 8.773] | 18.801 [18.801, 18.801] | 680.625 [680.625, 680.625] | 0 / 338 of 338 | 0.316 [0.316, 0.316] / no |
| end-to-end / node / upload-integrity / 64 | 784.793 [784.793, 784.793] | 78.222 [78.222, 78.222] | 143.071 [143.071, 143.071] | 745.141 [745.141, 745.141] | 0 / 379 of 379 | 0.305 [0.305, 0.305] / no |
| end-to-end / node / gzip-export / 1 | 269.764 [269.764, 269.764] | 3.349 [3.349, 3.349] | 5.472 [5.472, 5.472] | 757.563 [757.563, 757.563] | 0 / 108 of 108 | 0.226 [0.226, 0.226] / no |
| end-to-end / node / gzip-export / 8 | 383.614 [383.614, 383.614] | 18.456 [18.456, 18.456] | 40.739 [40.739, 40.739] | 770.594 [770.594, 770.594] | 0 / 162 of 162 | 0.370 [0.370, 0.370] / no |
| end-to-end / node / gzip-export / 64 | 403.514 [403.514, 403.514] | 151.560 [151.560, 151.560] | 245.292 [245.292, 245.292] | 803.078 [803.078, 803.078] | 0 / 224 of 224 | 0.334 [0.334, 0.334] / no |
| end-to-end / node / revenue / 1 | 388.488 [388.488, 388.488] | 2.507 [2.507, 2.507] | 3.217 [3.217, 3.217] | 761.109 [761.109, 761.109] | 0 / 156 of 156 | 0.149 [0.149, 0.149] / no |
| end-to-end / node / revenue / 8 | 480.756 [480.756, 480.756] | 14.514 [14.514, 14.514] | 31.155 [31.155, 31.155] | 762.000 [762.000, 762.000] | 0 / 200 of 200 | 0.149 [0.149, 0.149] / no |
| end-to-end / node / revenue / 64 | 478.323 [478.323, 478.323] | 129.819 [129.819, 129.819] | 260.032 [260.032, 260.032] | 762.031 [762.031, 762.031] | 0 / 255 of 255 | 0.138 [0.138, 0.138] / no |
| end-to-end / node / image-histogram / 1 | 634.062 [634.062, 634.062] | 1.357 [1.357, 1.357] | 3.195 [3.195, 3.195] | 762.703 [762.703, 762.703] | 0 / 254 of 254 | 0.276 [0.276, 0.276] / no |
| end-to-end / node / image-histogram / 8 | 772.674 [772.674, 772.674] | 9.484 [9.484, 9.484] | 19.955 [19.955, 19.955] | 762.891 [762.891, 762.891] | 0 / 317 of 317 | 0.334 [0.334, 0.334] / no |
| end-to-end / node / image-histogram / 64 | 777.090 [777.090, 777.090] | 79.795 [79.795, 79.795] | 154.694 [154.694, 154.694] | 811.297 [811.297, 811.297] | 0 / 371 of 371 | 0.325 [0.325, 0.325] / no |
| end-to-end / node / nearby-stores / 1 | 655.873 [655.873, 655.873] | 1.440 [1.440, 1.440] | 2.322 [2.322, 2.322] | 812.500 [812.500, 812.500] | 0 / 263 of 263 | 0.156 [0.156, 0.156] / no |
| end-to-end / node / nearby-stores / 8 | 994.678 [994.678, 994.678] | 6.975 [6.975, 6.975] | 15.602 [15.602, 15.602] | 812.563 [812.563, 812.563] | 0 / 405 of 405 | 0.192 [0.192, 0.192] / no |
| end-to-end / node / nearby-stores / 64 | 1012.015 [1012.015, 1012.015] | 61.437 [61.437, 61.437] | 121.708 [121.708, 121.708] | 803.219 [803.219, 803.219] | 0 / 470 of 470 | 0.215 [0.215, 0.215] / no |
| end-to-end / node / hello / 1 | 3688.578 [3688.578, 3688.578] | 0.217 [0.217, 0.217] | 1.343 [1.343, 1.343] | 803.500 [803.500, 803.500] | 0 / 1476 of 1476 | 0.324 [0.324, 0.324] / no |
| end-to-end / node / hello / 8 | 7291.033 [7291.033, 7291.033] | 0.847 [0.847, 0.847] | 3.513 [3.513, 3.513] | 804.000 [804.000, 804.000] | 0 / 2923 of 2923 | 0.471 [0.471, 0.471] / no |
| end-to-end / node / hello / 64 | 7309.114 [7309.114, 7309.114] | 7.771 [7.771, 7.771] | 17.009 [17.009, 17.009] | 836.094 [836.094, 836.094] | 0 / 2979 of 2979 | 0.512 [0.512, 0.512] / no |
| end-to-end / node / primes / 1 | 234.607 [234.607, 234.607] | 3.806 [3.806, 3.806] | 9.864 [9.864, 9.864] | 835.906 [835.906, 835.906] | 0 / 94 of 94 | 0.095 [0.095, 0.095] / no |
| end-to-end / node / primes / 8 | 285.851 [285.851, 285.851] | 25.939 [25.939, 25.939] | 52.084 [52.084, 52.084] | 835.500 [835.500, 835.500] | 0 / 121 of 121 | 0.108 [0.108, 0.108] / no |
| end-to-end / node / primes / 64 | 322.320 [322.320, 322.320] | 191.697 [191.697, 191.697] | 383.399 [383.399, 383.399] | 835.531 [835.531, 835.531] | 0 / 193 of 193 | 0.080 [0.080, 0.080] / no |
| end-to-end / native / login / 1 | 0.146 [0.146, 0.146] | 6826.279 [6826.279, 6826.279] | 6858.236 [6858.236, 6858.236] | 201.547 [201.547, 201.547] | 0 / 3 of 3 | 0.000 [0.000, 0.000] / no |
| end-to-end / native / login-scrypt / 1 | 14.050 [14.050, 14.050] | 70.680 [70.680, 70.680] | 72.631 [72.631, 72.631] | 235.938 [235.938, 235.938] | 0 / 3 of 3 | 0.014 [0.014, 0.014] / no |
| end-to-end / native / verify / 1 | 4388.144 [4388.144, 4388.144] | 0.204 [0.204, 0.204] | 0.354 [0.354, 0.354] | 373.172 [373.172, 373.172] | 0 / 1756 of 1756 | 0.311 [0.311, 0.311] / no |
| end-to-end / native / verify / 8 | 11596.542 [11596.542, 11596.542] | 0.639 [0.639, 0.639] | 3.278 [3.278, 3.278] | 446.047 [446.047, 446.047] | 0 / 4652 of 4652 | 0.626 [0.626, 0.626] / no |
| end-to-end / native / verify / 64 | 12911.029 [12911.029, 12911.029] | 4.555 [4.555, 4.555] | 9.923 [9.923, 9.923] | 454.813 [454.813, 454.813] | 0 / 5243 of 5243 | 0.635 [0.635, 0.635] / no |
| end-to-end / native / search / 1 | 305.229 [305.229, 305.229] | 3.169 [3.169, 3.169] | 4.151 [4.151, 4.151] | 458.172 [458.172, 458.172] | 0 / 123 of 123 | 0.099 [0.099, 0.099] / no |
| end-to-end / native / search / 8 | 453.744 [453.744, 453.744] | 17.563 [17.563, 17.563] | 20.034 [20.034, 20.034] | 457.938 [457.938, 457.938] | 0 / 185 of 185 | 0.077 [0.077, 0.077] / no |
| end-to-end / native / search / 64 | 452.526 [452.526, 452.526] | 138.032 [138.032, 138.032] | 147.848 [147.848, 147.848] | 458.766 [458.766, 458.766] | 0 / 193 of 193 | 0.056 [0.056, 0.056] / no |
| end-to-end / native / markdown / 1 | 53.163 [53.163, 53.163] | 18.589 [18.589, 18.589] | 20.086 [20.086, 20.086] | 465.047 [465.047, 465.047] | 0 / 22 of 22 | 0.022 [0.022, 0.022] / no |
| end-to-end / native / markdown / 8 | 55.361 [55.361, 55.361] | 143.881 [143.881, 143.881] | 146.371 [146.371, 146.371] | 466.344 [466.344, 466.344] | 0 / 25 of 25 | 0.013 [0.013, 0.013] / no |
| end-to-end / native / markdown / 64 | 53.561 [53.561, 53.561] | 1194.997 [1194.997, 1194.997] | 1195.371 [1195.371, 1195.371] | 468.906 [468.906, 468.906] | 0 / 65 of 65 | 0.010 [0.010, 0.010] / no |
| end-to-end / native / feed / 1 | 42.425 [42.425, 42.425] | 23.493 [23.493, 23.493] | 23.831 [23.831, 23.831] | 475.188 [475.188, 475.188] | 0 / 17 of 17 | 0.021 [0.021, 0.021] / no |
| end-to-end / native / feed / 8 | 44.587 [44.587, 44.587] | 179.542 [179.542, 179.542] | 180.904 [180.904, 180.904] | 476.078 [476.078, 476.078] | 0 / 25 of 25 | 0.011 [0.011, 0.011] / no |
| end-to-end / native / feed / 64 | 44.049 [44.049, 44.049] | 1452.679 [1452.679, 1452.679] | 1453.838 [1453.838, 1453.838] | 479.031 [479.031, 479.031] | 0 / 65 of 65 | 0.011 [0.011, 0.011] / no |
| end-to-end / native / upload-integrity / 1 | 196.757 [196.757, 196.757] | 4.971 [4.971, 4.971] | 6.008 [6.008, 6.008] | 513.375 [513.375, 513.375] | 0 / 79 of 79 | 0.107 [0.107, 0.107] / no |
| end-to-end / native / upload-integrity / 8 | 233.759 [233.759, 233.759] | 33.949 [33.949, 33.949] | 37.398 [37.398, 37.398] | 546.719 [546.719, 546.719] | 0 / 97 of 97 | 0.099 [0.099, 0.099] / no |
| end-to-end / native / upload-integrity / 64 | 229.239 [229.239, 229.239] | 269.770 [269.770, 269.770] | 309.296 [309.296, 309.296] | 795.266 [795.266, 795.266] | 0 / 133 of 133 | 0.081 [0.081, 0.081] / no |
| end-to-end / native / gzip-export / 1 | 390.173 [390.173, 390.173] | 2.269 [2.269, 2.269] | 4.278 [4.278, 4.278] | 804.641 [804.641, 804.641] | 0 / 157 of 157 | 0.305 [0.305, 0.305] / no |
| end-to-end / native / gzip-export / 8 | 678.139 [678.139, 678.139] | 11.560 [11.560, 11.560] | 15.365 [15.365, 15.365] | 805.781 [805.781, 805.781] | 0 / 277 of 277 | 0.501 [0.501, 0.501] / no |
| end-to-end / native / gzip-export / 64 | 655.511 [655.511, 655.511] | 93.640 [93.640, 93.640] | 112.501 [112.501, 112.501] | 808.781 [808.781, 808.781] | 0 / 321 of 321 | 0.492 [0.492, 0.492] / no |
| end-to-end / native / revenue / 1 | 928.712 [928.712, 928.712] | 1.013 [1.013, 1.013] | 1.382 [1.382, 1.382] | 819.266 [819.266, 819.266] | 0 / 372 of 372 | 0.220 [0.220, 0.220] / no |
| end-to-end / native / revenue / 8 | 1405.650 [1405.650, 1405.650] | 5.631 [5.631, 5.631] | 7.016 [7.016, 7.016] | 820.000 [820.000, 820.000] | 0 / 570 of 570 | 0.230 [0.230, 0.230] / no |
| end-to-end / native / revenue / 64 | 1389.105 [1389.105, 1389.105] | 45.367 [45.367, 45.367] | 53.499 [53.499, 53.499] | 844.625 [844.625, 844.625] | 0 / 601 of 601 | 0.181 [0.181, 0.181] / no |
| end-to-end / native / image-histogram / 1 | 466.451 [466.451, 466.451] | 1.892 [1.892, 1.892] | 4.145 [4.145, 4.145] | 858.297 [858.297, 858.297] | 0 / 188 of 188 | 0.220 [0.220, 0.220] / no |
| end-to-end / native / image-histogram / 8 | 783.187 [783.187, 783.187] | 10.006 [10.006, 10.006] | 16.167 [16.167, 16.167] | 914.969 [914.969, 914.969] | 0 / 319 of 319 | 0.305 [0.305, 0.305] / no |
| end-to-end / native / image-histogram / 64 | 774.145 [774.145, 774.145] | 80.695 [80.695, 80.695] | 107.521 [107.521, 107.521] | 1105.875 [1105.875, 1105.875] | 0 / 353 of 353 | 0.268 [0.268, 0.268] / no |
| end-to-end / native / nearby-stores / 1 | 763.873 [763.873, 763.873] | 1.242 [1.242, 1.242] | 2.222 [2.222, 2.222] | 1084.359 [1084.359, 1084.359] | 0 / 306 of 306 | 0.197 [0.197, 0.197] / no |
| end-to-end / native / nearby-stores / 8 | 1113.674 [1113.674, 1113.674] | 7.127 [7.127, 7.127] | 8.345 [8.345, 8.345] | 1082.406 [1082.406, 1082.406] | 0 / 453 of 453 | 0.167 [0.167, 0.167] / no |
| end-to-end / native / nearby-stores / 64 | 1112.140 [1112.140, 1112.140] | 56.701 [56.701, 56.701] | 62.595 [62.595, 62.595] | 1083.438 [1083.438, 1083.438] | 0 / 464 of 464 | 0.142 [0.142, 0.142] / no |
| end-to-end / native / hello / 1 | 6187.130 [6187.130, 6187.130] | 0.141 [0.141, 0.141] | 0.255 [0.255, 0.255] | 1084.453 [1084.453, 1084.453] | 0 / 2476 of 2476 | 0.374 [0.374, 0.374] / no |
| end-to-end / native / hello / 8 | 13771.898 [13771.898, 13771.898] | 0.529 [0.529, 0.529] | 3.060 [3.060, 3.060] | 1123.156 [1123.156, 1123.156] | 0 / 5514 of 5514 | 0.703 [0.703, 0.703] / no |
| end-to-end / native / hello / 64 | 13963.934 [13963.934, 13963.934] | 4.353 [4.353, 4.353] | 8.511 [8.511, 8.511] | 1143.328 [1143.328, 1143.328] | 0 / 5676 of 5676 | 0.677 [0.677, 0.677] / no |
| end-to-end / native / primes / 1 | 261.772 [261.772, 261.772] | 3.776 [3.776, 3.776] | 4.009 [4.009, 4.009] | 1146.953 [1146.953, 1146.953] | 0 / 105 of 105 | 0.086 [0.086, 0.086] / no |
| end-to-end / native / primes / 8 | 308.792 [308.792, 308.792] | 25.693 [25.693, 25.693] | 27.439 [27.439, 27.439] | 1147.063 [1147.063, 1147.063] | 0 / 129 of 129 | 0.061 [0.061, 0.061] / no |
| end-to-end / native / primes / 64 | 309.204 [309.204, 309.204] | 206.252 [206.252, 206.252] | 212.691 [212.691, 212.691] | 1147.984 [1147.984, 1147.984] | 0 / 157 of 157 | 0.047 [0.047, 0.047] / no |

## Observed native proxy/topology cost

| Route / C | Δ median p50 ms | Δ median p99 ms | end-to-end/direct req/s | Client saturation suspected |
| --- | --- | --- | --- | --- |


## Event-loop isolation (each repetition)

| Runtime / window / repeat | Light group relation | Probe | Requests | p50 ms | p99 ms | Heavy completed |
| --- | --- | --- | --- | --- | --- | --- |
| node / login / isolation-idle / 0 | outside | / | 35 | 1.334 | 6.699 | none |
| node / login / isolation-idle / 0 | outside | /api/hello | 35 | 1.967 | 5.241 | none |
| node / login / isolation-loaded / 0 | outside | / | 10 | 64.640 | 74.488 | 12 |
| node / login / isolation-loaded / 0 | outside | /api/hello | 9 | 64.510 | 159.552 | 12 |
| node / login-scrypt / isolation-idle / 0 | outside | / | 35 | 1.255 | 5.578 | none |
| node / login-scrypt / isolation-idle / 0 | outside | /api/hello | 35 | 1.720 | 4.114 | none |
| node / login-scrypt / isolation-loaded / 0 | outside | / | 36 | 1.099 | 2.083 | 16 |
| node / login-scrypt / isolation-loaded / 0 | outside | /api/hello | 36 | 1.479 | 2.282 | 16 |
| node / primes / isolation-idle / 0 | outside | / | 36 | 1.152 | 6.670 | none |
| node / primes / isolation-idle / 0 | outside | /api/hello | 36 | 1.528 | 5.259 | none |
| node / primes / isolation-loaded / 0 | outside | / | 12 | 48.409 | 56.727 | 28 |
| node / primes / isolation-loaded / 0 | outside | /api/hello | 12 | 48.292 | 57.099 | 28 |
| node / gzip-export / isolation-idle / 0 | inside | / | 35 | 1.072 | 6.975 | none |
| node / gzip-export / isolation-idle / 0 | inside | /api/hello | 35 | 1.264 | 5.509 | none |
| node / gzip-export / isolation-loaded / 0 | inside | / | 36 | 1.309 | 8.866 | 266 |
| node / gzip-export / isolation-loaded / 0 | inside | /api/hello | 36 | 1.581 | 9.768 | 266 |
| native / login / isolation-idle / 0 | outside | / | 35 | 1.362 | 7.344 | none |
| native / login / isolation-idle / 0 | outside | /api/hello | 35 | 1.772 | 5.724 | none |
| native / login / isolation-loaded / 0 | outside | / | 35 | 1.168 | 3.226 | 1 |
| native / login / isolation-loaded / 0 | outside | /api/hello | 35 | 1.454 | 3.602 | 1 |
| native / login-scrypt / isolation-idle / 0 | outside | / | 35 | 1.287 | 5.906 | none |
| native / login-scrypt / isolation-idle / 0 | outside | /api/hello | 35 | 1.587 | 4.277 | none |
| native / login-scrypt / isolation-loaded / 0 | outside | / | 35 | 1.180 | 2.175 | 15 |
| native / login-scrypt / isolation-loaded / 0 | outside | /api/hello | 35 | 1.482 | 2.638 | 15 |
| native / primes / isolation-idle / 0 | outside | / | 35 | 1.207 | 6.129 | none |
| native / primes / isolation-idle / 0 | outside | /api/hello | 35 | 1.507 | 4.609 | none |
| native / primes / isolation-loaded / 0 | outside | / | 36 | 1.144 | 1.730 | 28 |
| native / primes / isolation-loaded / 0 | outside | /api/hello | 36 | 1.427 | 2.617 | 28 |
| native / gzip-export / isolation-idle / 0 | inside | / | 35 | 1.266 | 5.906 | none |
| native / gzip-export / isolation-idle / 0 | inside | /api/hello | 35 | 1.553 | 4.462 | none |
| native / gzip-export / isolation-loaded / 0 | inside | / | 38 | 0.935 | 2.798 | 410 |
| native / gzip-export / isolation-loaded / 0 | inside | /api/hello | 38 | 1.168 | 2.797 | 410 |

## Synthetic threads: sharing ergonomics and overhead

| Variant / workers | Internal ms median [min,max] | Warmed total RSS MiB median [min,max] |
| --- | --- | --- |
| node-objects-clone / 1 | 1434.969 [1434.969, 1434.969] | 997.938 [997.938, 997.938] |
| node-objects-clone / 2 | 1101.812 [1101.812, 1101.812] | 1332.734 [1332.734, 1332.734] |
| node-objects-clone / 4 | 363.194 [363.194, 363.194] | 1784.766 [1784.766, 1784.766] |
| node-sab / 1 | 1438.805 [1438.805, 1438.805] | 83.641 [83.641, 83.641] |
| node-sab / 2 | 976.952 [976.952, 976.952] | 94.750 [94.750, 94.750] |
| node-sab / 4 | 366.354 [366.354, 366.354] | 116.313 [116.313, 116.313] |
| native-published-objects / 1 | 1112.532 [1112.532, 1112.532] | 107.297 [107.297, 107.297] |
| native-published-objects / 2 | 554.950 [554.950, 554.950] | 107.656 [107.656, 107.656] |
| native-published-objects / 4 | 276.949 [276.949, 276.949] | 108.188 [108.188, 108.188] |

Same-process net RSS growth from 1 to 4 warmed workers; not allocation size. See the threads definition.

| Variant | 1-worker RSS MiB | 4-worker RSS MiB | Marginal warmed RSS / added worker MiB |
| --- | --- | --- | --- |
| node-objects-clone | 997.938 | 1784.766 | 262.276 |
| node-sab | 83.641 | 116.313 | 10.891 |
| native-published-objects | 107.297 | 108.188 | 0.297 |

## Precise metric definitions

- **cold-start:** Monotonic wall time immediately before spawn to the first HTTP response with expected status and fully drained body. Fresh process each sample; readiness retries every 2 ms. Direct uses the exact generated .next/scriptc/entry-N.ts under Node 24 type stripping versus its compiled binary; no Next. End-to-end includes next start (Node) or the recorded native production command and the first execution of the specified route. OS filesystem caches are not flushed; this is process-cold, not machine-cold. Median averages the middle two values for even N; p90 uses nearest rank.
- **memory-idle:** RSS after first successful readiness request and the configured quiet interval. Includes initialization by that route, not an untouched process. Direct: route process. End-to-end: entire owned process tree, including Next, adapter supervisor, all native binaries and descendants. Linux uses the kernel's approximate stat RSS counter; macOS uses ps RSS. Totals sum resident mappings and may double-count shared OS/library pages; not PSS or unique physical memory.
- **cpu-fixed-count:** After untimed warmup, user+system CPU delta of the stable owned process tree over exactly N successful sequential keep-alive requests, divided by N. Linux /proc/PID/stat excludes child CPU fields to avoid double counting; Node worker threads are already in process totals. macOS ps TIME is rounded to centiseconds. The generator warms its own process and keep-alive agent before an IPC barrier; CPU snapshots bracket release through generator shutdown, excluding spawn/warmup. Boundary sampling and idle runtime CPU remain; generator CPU is excluded and reported separately. Each row carries before/after per-process CPU and RSS. N is per repetition, after prior warmup; RSS after N is not a fresh-process measurement.
- **throughput-latency:** Separate-process HTTP/1.1 keep-alive closed-loop generator with C outstanding requests, no pipelining; dispatch until duration expires, then drain all in-flight requests. Throughput = completed responses / actual dispatch-to-final-drain seconds. Latency = dispatch to fully drained body; nearest-rank p50/p99 within a run. No coordinated-omission correction; this measures closed-loop capacity, not an external arrival-rate SLA. Each sample warms the same generator process and agent at its C before the IPC start barrier. Socket creations and reused requests are counted separately for warmup and measurement; repeats retained independently, with median and min/max across runs.
- **peak-rss:** Largest sampled simultaneous sum of process-tree RSS, sampled every 100 ms plus the before/after boundaries. Sampler reads only the previously discovered tree (targeted ps on macOS, /proc on Linux); full discovery at both boundaries checks stable process membership. Each peak snapshot contains every process. This is a lower bound on peak RSS, not a kernel high-water mark. On a loaded host ps/scheduling can lengthen the interval.
- **hop-cost:** Native end-to-end minus native direct median p50/p99 at identical concurrency, input and affinity. Also report end-to-end/direct throughput ratio. This is an observed topology difference including Next routing/proxy/serialization/scheduling, not a pure network-hop stopwatch. The samples are separate runs; percentile differences are not percentiles of paired hop times and may be negative under noise.
- **isolation:** First warm heavy and probe endpoints. Baseline and loaded windows each dispatch one sequential probe per path, in parallel, waiting 20 ms after completion. Loaded window additionally holds one heavy request outstanding, back to back. Record probe p50/p99 and sample counts alongside completed heavy requests; equal offered concurrency, not equal achieved heavy RPS. Heavy load starts 100 ms before probes; drain is included. A synchronous Node handler may delay even accepting probes. Requests cannot be preempted at the deadline.
- **threads:** One million orders, 8 regions, 12 scenarios, 60 months; exact integer-cent totals compared across all variants/counts. Fresh process per variant, growing its retained pool through 1/2/4 workers. One readiness computation at 1 worker, then two full warmups at each count before repeated internal dispatch+compute+reduction timings. Counts run ascending and share JIT/GC history. Dataset/pool setup and HTTP excluded. RSS includes the dataset and all worker threads. Marginal warmed RSS/added worker = (median post-job RSS at 4 workers - median post-job RSS at 1 worker) / 3 within that SAME process. The instantaneous dataset-construction RSS is no longer the baseline; this measures net resident growth including GC/JIT/allocator history, not exact clone allocations. Negative values, if any, remain visible as GC/noise and do not mean negative worker allocation. SAB uses four hand-filled Int32 SharedArrayBuffers; object variants share the original route and worker source. Node object workers clone workerData; native publishes ordinary object graphs. No forced GC.
