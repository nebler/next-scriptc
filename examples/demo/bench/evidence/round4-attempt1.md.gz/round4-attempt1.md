# next-scriptc benchmark

**INDICATIVE ONLY: developer machine / reduced repetitions; not publishable performance evidence**

Status: failed. Commit: 0ca22f537d11df1f4594b7cac6d73ce05b36cd89. Node v24.22.0; scriptc 0.4.6; Next 16.4.3.

Apple M4 Pro; 12 logical CPUs; darwin/arm64; load averages start 10.24853515625, 7.64453125, 5.91259765625, end 14.4140625, 10.1611328125, 7.205078125.

Started 2026-10-31T02:29:41.162Z; ended 2026-10-31T02:32:36.804Z. Profile: quick. Affinity: {}.

Full environment, build IDs, source/binary hashes, dirty status, raw repetitions, per-process snapshots, requests, and workload configuration are in the adjacent JSON. Brackets below are [min, max] across repeated runs, not confidence intervals.


## Final production summary — wins and losses together

Every HTTP workload appears below. Values are medians of measured end-to-end rows, followed by variant/Node ratios; 1× is parity. Each column states its ratio direction. Passwords have no C=64 measurement. Asterisk means suspected generator saturation in the variant or Node baseline (throughput is then a lower bound on capacity). No direct measurement fills a production cell. Missing, refused and failed cells stay explicit.

| Workload | Configuration | C=1 p50 ms; ratio to Node (lower is better) | C=64 req/s; ratio to Node (higher is better) | CPU ms/request; ratio to Node (lower is better) | Cold ms; ratio to Node (lower is better) |
| --- | --- | --- | --- | --- | --- |
| login | node | not measured (section absent/incomplete) | unmeasured (bounded C=1) | not measured (section absent/incomplete) | 628.822; 1.000× |
| login | native | not measured (section absent/incomplete) | unmeasured (bounded C=1) | not measured (section absent/incomplete) | 8175.379; 13.001× |
| login | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| login-scrypt | node | not measured (section absent/incomplete) | unmeasured (bounded C=1) | not measured (section absent/incomplete) | 447.158; 1.000× |
| login-scrypt | native | not measured (section absent/incomplete) | unmeasured (bounded C=1) | not measured (section absent/incomplete) | 399.703; 0.894× |
| login-scrypt | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| verify | node | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 318.587; 1.000× |
| verify | native | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 316.525; 0.994× |
| verify | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| search | node | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 371.505; 1.000× |
| search | native | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 508.488; 1.369× |
| search | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| markdown | node | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 340.250; 1.000× |
| markdown | native | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 341.468; 1.004× |
| markdown | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| feed | node | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 342.722; 1.000× |
| feed | native | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 342.996; 1.001× |
| feed | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| upload-integrity | node | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 316.176; 1.000× |
| upload-integrity | native | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 327.954; 1.037× |
| upload-integrity | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| gzip-export | node | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 321.823; 1.000× |
| gzip-export | native | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 320.580; 0.996× |
| gzip-export | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| revenue | node | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 318.292; 1.000× |
| revenue | native | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 320.714; 1.008× |
| revenue | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| image-histogram | node | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 316.885; 1.000× |
| image-histogram | native | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 327.890; 1.035× |
| image-histogram | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| nearby-stores | node | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 311.480; 1.000× |
| nearby-stores | native | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 326.152; 1.047× |
| nearby-stores | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| hello | node | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 309.913; 1.000× |
| hello | native | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 329.681; 1.064× |
| hello | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| primes | node | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 322.267; 1.000× |
| primes | native | not measured (section absent/incomplete) | not measured (section absent/incomplete) | not measured (section absent/incomplete) | 322.769; 1.002× |
| primes | native-grouped | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |
| csv | node | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists |
| csv | native | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists |
| csv | native-grouped | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists | refused: Papa Parse unparse refused in route probe; no CSV route exists |

Whole-app summed RSS includes Next, supervisor and every resident native process. Idle follows hello readiness. Loaded is the maximum simultaneous sampled RSS across all production CPU/throughput rows in the fixed workload order, including allocator/GC history; it is not PSS or a kernel peak. Both ratios below are variant/Node, **lower is better**.

| Configuration | Idle MiB; ratio to Node (lower is better) | Loaded MiB; ratio to Node (lower is better) | Status |
| --- | --- | --- | --- |
| node | 71.953; 1.000× | not measured | not measured (production absent/incomplete) |
| native | not measured | not measured | not measured (production absent/incomplete) |
| native-grouped | not measured | not measured | skipped: .next-grouped does not exist; local quick verification covers Node vs native only |

Sections completed: none. Omitted sections are absent, not zero. Native-grouped is production-only; direct and internal-worker rows remain Node/native.


## Limitations alongside the results

- Headline application workloads are successful cost-10 bcrypt login, async scrypt login (N=32768, r=8, p=1), authenticated JWT verification, 3,000-product search, uncached Markdown rendering, RSS, 1 MiB upload integrity, gzip export, revenue aggregation, raw RGBA histogram and nearby-store search. hello is a small-response control; primes and report are synthetic. These fixtures have no database or remote I/O.
- Native bcrypt is a known regression: the earlier correctness probe took 26.8 s for three cost-10 operations versus 0.56 s on Node (~48× slower). Login therefore measures only three requests, C=1, one measured repetition and one separate cold request per surface. Its p99 is simply the maximum of three, not credible tail evidence. No reduced cost, invalid password or 401 shortcut is substituted. CSV and OG-image generation were refused by the probe; see examples/probe/RESULTS.md.
- If a route exceeds Next’s default 30-second upstream proxy timeout, production returns HTTP 500. The suite records that workload as exceeding the default 30 s proxy timeout when elapsed time and upstream-reset logs confirm it, preserves server logs, sets dataset status failed/nonzero exit and continues independent workloads. It never increases the production timeout, substitutes a faster error path or counts failed responses as throughput.
- Coverage static percentage is not a typed-machine-code percentage: scriptc includes dynamic-tier statements in its compile-statically total. Dynamic counts and package modes are displayed alongside speed; package mode static does not exclude untyped JS operations. Coverage describes the entry graph, not measured hot-path time, so it suggests explanations without proving causality.
- Node baseline is a production next build / next start with adapter disabled (.next-node), normal V8 JIT, no debug or memory flags. Direct Node uses the identical generated entry and HTTP shim, without a Next server. Native end-to-end includes the extra Next proxy and all resident route processes. Native-grouped uses the registered eight-route light group; it shares scheduling, state and failure fate, and gzip isolation measures contention inside that group.
- hello reads Accept-Language and feed reads a result limit from request.url: with cacheComponents these are dynamic, and both sides compute every measured response. Node prerendered paths are recorded separately; no Next optimization is disabled. Async scrypt uses Node's default libuv threadpool; scriptc 0.4.6 computes the derivation before deferring the callback. Isolation includes both async scrypt and synchronous bcrypt, so a bcrypt isolation win does not describe production-style async password hashing.
- Linux uses two allowed CPUs for the application tree and two disjoint CPUs for generator + controller. Both runtimes inherit the same masks. Threads alone use all four CPUs for 1/2/4-worker scaling; they have no sustained HTTP load generator. These are logical CPUs; topology/SMT and other sandbox tenants may still affect results. macOS cannot use taskset: local output is indicative only.
- Run order: cold runtimes alternate. Default steady blocks are direct Node, direct native, end-to-end Node, end-to-end native, end-to-end native-grouped; --reverse reverses runtime order and is recorded in the profile. All repeated steady runs share their block's process/JIT/cache/allocator state. No multiple application modes run together. Repeat on a quiet host in both orders before publishing close comparisons.
- Client and server share a machine and memory bandwidth. The single Node generator can bottleneck on one JS thread even with a two-CPU affinity mask. Rows flag suspected generator saturation at >=0.8 CPU-seconds per wall-second; flagged throughput is a lower bound on server capacity. CPU pinning reduces CPU contention but does not eliminate shared-resource interference. No load-generator ceiling calibration is implied.
- SAB is a standalone Node program to expose the strongest Node sharing baseline without adding an application route. Its internal timed region matches report, and every total must match. It has no idle HTTP shim; RSS is therefore slightly favorable to SAB. SAB and object layouts/code accesses differ by necessity. This tests sharing ergonomics + overhead, not identical-code compiler speed. Dataset construction and worker initialization costs are excluded from time. Warmed total RSS retains the dataset and resident pool; the marginal metric compares warmed 1/4-worker states within a process.
- Idle and after-load memory are runtime/GC-state dependent. Peak sampling can miss spikes; summed RSS overcounts shared pages. CPU ticks can make tiny-request per-request CPU noisy: increase fixed count for public claims. Active CPU here is OS user+system process CPU, not a reproduction of Vercel billing instrumentation.
- Responses are checked for expected status and byte-for-byte SHA-256 parity before timing and throughout load. Gzip export checks decoded bytes and representation headers, allowing valid compressed encodings to differ; client decompression CPU is separate, while latency includes it on both runtimes. Workloads must use deterministic fixtures, including a fixed clock/key for token issuance. No TLS, remote network, serverless scheduling, multi-instance autoscaling or platform cold starts are measured.


## Workload fixtures

Node build prerendered paths: /, /_global-error, /_not-found, /api/items/new, /api/static-fixture, /favicon.ico.

| Route | Kind | Request / pending |
| --- | --- | --- |
| login | realistic | POST /api/login |
| login-scrypt | realistic | POST /api/login-scrypt |
| verify | realistic | GET /api/verify |
| search | realistic | GET /api/search?q=desk%20lamp&limit=7 |
| markdown | realistic | GET /api/posts/reliable-webhooks |
| feed | realistic | GET /api/feed.xml |
| upload-integrity | realistic | POST /api/uploads/verify |
| gzip-export | realistic | GET /api/export.json.gz?rows=5000 |
| revenue | realistic | GET /api/analytics/revenue?from=2026-01-01&to=2026-01-31 |
| image-histogram | realistic | POST /api/images/histogram?width=512&height=512 |
| nearby-stores | realistic | GET /api/stores/nearby?lat=51.5074&lng=-0.1278&radiusKm=1000 |
| hello | control | GET /api/hello |
| primes | synthetic | GET /api/primes?limit=1000000 |
| csv | refused | DISABLED: Papa Parse unparse refused in route probe; no CSV route exists |

## Application workloads, C=1 (latency and single-route coverage together)

| Route | Scope | Node p50 ms | Native p50 ms | Native / Node latency (lower is better) | Native-grouped p50 ms | Grouped / Node latency (lower is better) | Statements / static % / dynamic tier | Package modes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| login | direct | 86.226 | 8051.492 | 93.376× | production only | — | 2170 / 99% / 437 | bcryptjs: static; jose: static |
| login | end-to-end | — | — | — | SKIPPED (build absent) | — | 2170 / 99% / 437 | bcryptjs: static; jose: static |
| login-scrypt | direct | 65.128 | 82.939 | 1.273× | production only | — | 1756 / 99% / 238 | jose: static |
| login-scrypt | end-to-end | — | — | — | SKIPPED (build absent) | — | 1756 / 99% / 238 | jose: static |
| verify | direct | 0.116 | 0.087 | 0.747× | production only | — | 1784 / 99% / 252 | jose: static |
| verify | end-to-end | — | — | — | SKIPPED (build absent) | — | 1784 / 99% / 252 | jose: static |
| search | direct | 0.613 | 7.978 | 13.013× | production only | — | 1109 / 100% / 355 | minisearch: static |
| search | end-to-end | — | — | — | SKIPPED (build absent) | — | 1109 / 100% / 355 | minisearch: static |
| markdown | direct | 0.452 | 18.247 | 40.343× | production only | — | 1301 / 100% / 652 | marked: static |
| markdown | end-to-end | — | — | — | SKIPPED (build absent) | — | 1301 / 100% / 652 | marked: static |
| feed | direct | 0.620 | 44.083 | 71.054× | production only | — | 1305 / 100% / 653 | marked: static |
| feed | end-to-end | — | — | — | SKIPPED (build absent) | — | 1305 / 100% / 653 | marked: static |
| upload-integrity | direct | 1.003 | 4.601 | 4.587× | production only | — | 410 / 100% / 38 | none |
| upload-integrity | end-to-end | — | — | — | SKIPPED (build absent) | — | 410 / 100% / 38 | none |
| gzip-export | direct | 3.006 | 2.180 | 0.725× | production only | — | 409 / 100% / 37 | none |
| gzip-export | end-to-end | — | — | — | SKIPPED (build absent) | — | 409 / 100% / 37 | none |
| revenue | direct | 2.248 | 1.573 | 0.700× | production only | — | 435 / 100% / 37 | none |
| revenue | end-to-end | — | — | — | SKIPPED (build absent) | — | 435 / 100% / 37 | none |
| image-histogram | direct | 1.050 | 1.460 | 1.391× | production only | — | 421 / 100% / 41 | none |
| image-histogram | end-to-end | — | — | — | SKIPPED (build absent) | — | 421 / 100% / 41 | none |
| nearby-stores | direct | 0.937 | 1.102 | 1.175× | production only | — | 424 / 100% / 39 | none |
| nearby-stores | end-to-end | — | — | — | SKIPPED (build absent) | — | 424 / 100% / 39 | none |

## Coverage of every measured entry (controls and synthetic included)

| Entry | Statements | Static statements / % | Dynamic tier statements | Package modes |
| --- | --- | --- | --- | --- |
| login | 2170 | 2159 / 99% | 437 | bcryptjs: static; jose: static |
| login-scrypt | 1756 | 1745 / 99% | 238 | jose: static |
| verify | 1784 | 1773 / 99% | 252 | jose: static |
| search | 1109 | 1109 / 100% | 355 | minisearch: static |
| markdown | 1301 | 1301 / 100% | 652 | marked: static |
| feed | 1305 | 1305 / 100% | 653 | marked: static |
| upload-integrity | 410 | 410 / 100% | 38 | none |
| gzip-export | 409 | 409 / 100% | 37 | none |
| revenue | 435 | 435 / 100% | 37 | none |
| image-histogram | 421 | 421 / 100% | 41 | none |
| nearby-stores | 424 | 424 / 100% | 39 | none |
| hello | 404 | 404 / 100% | 35 | none |
| primes | 418 | 418 / 100% | 36 | none |
| report | 490 | 490 / 100% | 44 | none |

## Cold start (ms, process-cold)

| Scope / runtime / route | N | Median | p90 | Min | Max |
| --- | --- | --- | --- | --- | --- |
| direct / node / login | 1 | 228.760 | 228.760 | 228.760 | 228.760 |
| direct / native / login | 1 | 7325.768 | 7325.768 | 7325.768 | 7325.768 |
| direct / node / login-scrypt | 1 | 210.357 | 210.357 | 210.357 | 210.357 |
| direct / native / login-scrypt | 1 | 417.733 | 417.733 | 417.733 | 417.733 |
| direct / node / verify | 1 | 129.972 | 129.972 | 129.972 | 129.972 |
| direct / native / verify | 1 | 346.343 | 346.343 | 346.343 | 346.343 |
| direct / node / search | 1 | 177.557 | 177.557 | 177.557 | 177.557 |
| direct / native / search | 1 | 643.861 | 643.861 | 643.861 | 643.861 |
| direct / node / markdown | 1 | 138.984 | 138.984 | 138.984 | 138.984 |
| direct / native / markdown | 1 | 387.890 | 387.890 | 387.890 | 387.890 |
| direct / node / feed | 1 | 138.972 | 138.972 | 138.972 | 138.972 |
| direct / native / feed | 1 | 475.836 | 475.836 | 475.836 | 475.836 |
| direct / node / upload-integrity | 1 | 116.609 | 116.609 | 116.609 | 116.609 |
| direct / native / upload-integrity | 1 | 353.309 | 353.309 | 353.309 | 353.309 |
| direct / node / gzip-export | 1 | 118.137 | 118.137 | 118.137 | 118.137 |
| direct / native / gzip-export | 1 | 322.374 | 322.374 | 322.374 | 322.374 |
| direct / node / revenue | 1 | 114.990 | 114.990 | 114.990 | 114.990 |
| direct / native / revenue | 1 | 329.791 | 329.791 | 329.791 | 329.791 |
| direct / node / image-histogram | 1 | 115.145 | 115.145 | 115.145 | 115.145 |
| direct / native / image-histogram | 1 | 334.237 | 334.237 | 334.237 | 334.237 |
| direct / node / nearby-stores | 1 | 117.890 | 117.890 | 117.890 | 117.890 |
| direct / native / nearby-stores | 1 | 322.133 | 322.133 | 322.133 | 322.133 |
| direct / node / hello | 1 | 107.917 | 107.917 | 107.917 | 107.917 |
| direct / native / hello | 1 | 342.373 | 342.373 | 342.373 | 342.373 |
| direct / node / primes | 1 | 116.236 | 116.236 | 116.236 | 116.236 |
| direct / native / primes | 1 | 334.048 | 334.048 | 334.048 | 334.048 |
| end-to-end / node / login | 1 | 628.822 | 628.822 | 628.822 | 628.822 |
| end-to-end / native / login | 1 | 8175.379 | 8175.379 | 8175.379 | 8175.379 |
| end-to-end / node / login-scrypt | 1 | 447.158 | 447.158 | 447.158 | 447.158 |
| end-to-end / native / login-scrypt | 1 | 399.703 | 399.703 | 399.703 | 399.703 |
| end-to-end / node / verify | 1 | 318.587 | 318.587 | 318.587 | 318.587 |
| end-to-end / native / verify | 1 | 316.525 | 316.525 | 316.525 | 316.525 |
| end-to-end / node / search | 1 | 371.505 | 371.505 | 371.505 | 371.505 |
| end-to-end / native / search | 1 | 508.488 | 508.488 | 508.488 | 508.488 |
| end-to-end / node / markdown | 1 | 340.250 | 340.250 | 340.250 | 340.250 |
| end-to-end / native / markdown | 1 | 341.468 | 341.468 | 341.468 | 341.468 |
| end-to-end / node / feed | 1 | 342.722 | 342.722 | 342.722 | 342.722 |
| end-to-end / native / feed | 1 | 342.996 | 342.996 | 342.996 | 342.996 |
| end-to-end / node / upload-integrity | 1 | 316.176 | 316.176 | 316.176 | 316.176 |
| end-to-end / native / upload-integrity | 1 | 327.954 | 327.954 | 327.954 | 327.954 |
| end-to-end / node / gzip-export | 1 | 321.823 | 321.823 | 321.823 | 321.823 |
| end-to-end / native / gzip-export | 1 | 320.580 | 320.580 | 320.580 | 320.580 |
| end-to-end / node / revenue | 1 | 318.292 | 318.292 | 318.292 | 318.292 |
| end-to-end / native / revenue | 1 | 320.714 | 320.714 | 320.714 | 320.714 |
| end-to-end / node / image-histogram | 1 | 316.885 | 316.885 | 316.885 | 316.885 |
| end-to-end / native / image-histogram | 1 | 327.890 | 327.890 | 327.890 | 327.890 |
| end-to-end / node / nearby-stores | 1 | 311.480 | 311.480 | 311.480 | 311.480 |
| end-to-end / native / nearby-stores | 1 | 326.152 | 326.152 | 326.152 | 326.152 |
| end-to-end / node / hello | 1 | 309.913 | 309.913 | 309.913 | 309.913 |
| end-to-end / native / hello | 1 | 329.681 | 329.681 | 329.681 | 329.681 |
| end-to-end / node / primes | 1 | 322.267 | 322.267 | 322.267 | 322.267 |
| end-to-end / native / primes | 1 | 322.769 | 322.769 | 322.769 | 322.769 |

## Idle RSS (MiB, per process and simultaneous total)

| Scope / runtime | Initialized by | PID / role | RSS MiB |
| --- | --- | --- | --- |
| direct / node | login | 2813 / node-route | 103.594 |
| direct / node | login | TOTAL | 103.594 |
| direct / node | login-scrypt | 2944 / node-route | 136.156 |
| direct / node | login-scrypt | TOTAL | 136.156 |
| direct / node | verify | 3054 / node-route | 102.391 |
| direct / node | verify | TOTAL | 102.391 |
| direct / node | search | 3380 / node-route | 117.266 |
| direct / node | search | TOTAL | 117.266 |
| direct / node | markdown | 3715 / node-route | 97.953 |
| direct / node | markdown | TOTAL | 97.953 |
| direct / node | feed | 4028 / node-route | 97.766 |
| direct / node | feed | TOTAL | 97.766 |
| direct / node | upload-integrity | 4341 / node-route | 94.781 |
| direct / node | upload-integrity | TOTAL | 94.781 |
| direct / node | gzip-export | 4663 / node-route | 100.563 |
| direct / node | gzip-export | TOTAL | 100.563 |
| direct / node | revenue | 5054 / node-route | 99.109 |
| direct / node | revenue | TOTAL | 99.109 |
| direct / node | image-histogram | 5404 / node-route | 99.063 |
| direct / node | image-histogram | TOTAL | 99.063 |
| direct / node | nearby-stores | 5735 / node-route | 106.344 |
| direct / node | nearby-stores | TOTAL | 106.344 |
| direct / node | hello | 6076 / node-route | 94.047 |
| direct / node | hello | TOTAL | 94.047 |
| direct / node | primes | 6403 / node-route | 95.719 |
| direct / node | primes | TOTAL | 95.719 |
| direct / native | login | 6754 / native-route | 5.125 |
| direct / native | login | TOTAL | 5.125 |
| direct / native | login-scrypt | 11836 / native-route | 36.906 |
| direct / native | login-scrypt | TOTAL | 36.906 |
| direct / native | verify | 11961 / native-route | 4.734 |
| direct / native | verify | TOTAL | 4.734 |
| direct / native | search | 12289 / native-route | 28.375 |
| direct / native | search | TOTAL | 28.375 |
| direct / native | markdown | 12646 / native-route | 8.953 |
| direct / native | markdown | TOTAL | 8.953 |
| direct / native | feed | 13263 / native-route | 8.875 |
| direct / native | feed | TOTAL | 8.875 |
| direct / native | upload-integrity | 14081 / native-route | 6.531 |
| direct / native | upload-integrity | TOTAL | 6.531 |
| direct / native | gzip-export | 15897 / native-route | 5.234 |
| direct / native | gzip-export | TOTAL | 5.234 |
| direct / native | revenue | 16371 / native-route | 5.188 |
| direct / native | revenue | TOTAL | 5.188 |
| direct / native | image-histogram | 16692 / native-route | 6.391 |
| direct / native | image-histogram | TOTAL | 6.391 |
| direct / native | nearby-stores | 17007 / native-route | 5.031 |
| direct / native | nearby-stores | TOTAL | 5.031 |
| direct / native | hello | 17501 / native-route | 3.063 |
| direct / native | hello | TOTAL | 3.063 |
| direct / native | primes | 17815 / native-route | 4.125 |
| direct / native | primes | TOTAL | 4.125 |
| end-to-end / node | hello | 18143 / next-server | 71.953 |
| end-to-end / node | hello | TOTAL | 71.953 |

## Fixed-count process CPU and memory

| Scope / runtime / route | N per run | CPU ms/request median [min,max] | After N total RSS MiB | Sampled peak total MiB |
| --- | --- | --- | --- | --- |
| direct / node / login | 3 | 90.000 [90.000, 90.000] | 104.594 [104.594, 104.594] | 104.594 [104.594, 104.594] |
| direct / node / login-scrypt | 3 | 66.667 [66.667, 66.667] | 136.594 [136.594, 136.594] | 136.594 [136.594, 136.594] |
| direct / node / verify | 40 | 0.750 [0.750, 0.750] | 107.563 [107.563, 107.563] | 107.563 [107.563, 107.563] |
| direct / node / search | 40 | 0.750 [0.750, 0.750] | 120.109 [120.109, 120.109] | 120.109 [120.109, 120.109] |
| direct / node / markdown | 40 | 0.500 [0.500, 0.500] | 107.922 [107.922, 107.922] | 107.922 [107.922, 107.922] |
| direct / node / feed | 40 | 0.500 [0.500, 0.500] | 110.188 [110.188, 110.188] | 110.188 [110.188, 110.188] |
| direct / node / upload-integrity | 40 | 1.250 [1.250, 1.250] | 196.406 [196.406, 196.406] | 196.406 [196.406, 196.406] |
| direct / node / gzip-export | 40 | 2.750 [2.750, 2.750] | 111.750 [111.750, 111.750] | 112.563 [112.563, 112.563] |
| direct / node / revenue | 40 | 2.000 [2.000, 2.000] | 112.828 [112.828, 112.828] | 112.828 [112.828, 112.828] |
| direct / node / image-histogram | 40 | 1.500 [1.500, 1.500] | 189.063 [189.063, 189.063] | 189.063 [189.063, 189.063] |
| direct / node / nearby-stores | 40 | 0.750 [0.750, 0.750] | 114.891 [114.891, 114.891] | 114.891 [114.891, 114.891] |
| direct / node / hello | 40 | 0.000 [0.000, 0.000] | 115.188 [115.188, 115.188] | 115.188 [115.188, 115.188] |
| direct / node / primes | 40 | 4.000 [4.000, 4.000] | 145.469 [145.469, 145.469] | 145.469 [145.469, 145.469] |
| direct / native / login | 3 | 8226.667 [8226.667, 8226.667] | 5.125 [5.125, 5.125] | 5.250 [5.250, 5.250] |
| direct / native / login-scrypt | 3 | 83.333 [83.333, 83.333] | 37.109 [37.109, 37.109] | 37.109 [37.109, 37.109] |
| direct / native / verify | 40 | 0.000 [0.000, 0.000] | 5.219 [5.219, 5.219] | 5.219 [5.219, 5.219] |
| direct / native / search | 40 | 5.000 [5.000, 5.000] | 29.594 [29.594, 29.594] | 29.594 [29.594, 29.594] |
| direct / native / markdown | 40 | 18.000 [18.000, 18.000] | 9.906 [9.906, 9.906] | 9.906 [9.906, 9.906] |
| direct / native / feed | 40 | 35.500 [35.500, 35.500] | 9.141 [9.141, 9.141] | 9.141 [9.141, 9.141] |
| direct / native / upload-integrity | 40 | 4.250 [4.250, 4.250] | 12.703 [12.703, 12.703] | 12.703 [12.703, 12.703] |
| direct / native / gzip-export | 40 | 1.750 [1.750, 1.750] | 7.438 [7.438, 7.438] | 7.438 [7.438, 7.438] |
| direct / native / revenue | 40 | 1.250 [1.250, 1.250] | 5.922 [5.922, 5.922] | 5.922 [5.922, 5.922] |
| direct / native / image-histogram | 40 | 1.250 [1.250, 1.250] | 10.422 [10.422, 10.422] | 10.422 [10.422, 10.422] |
| direct / native / nearby-stores | 40 | 1.000 [1.000, 1.000] | 5.484 [5.484, 5.484] | 5.484 [5.484, 5.484] |
| direct / native / hello | 40 | 0.000 [0.000, 0.000] | 3.438 [3.438, 3.438] | 3.438 [3.438, 3.438] |
| direct / native / primes | 40 | 3.250 [3.250, 3.250] | 6.453 [6.453, 6.453] | 6.453 [6.453, 6.453] |

## Throughput / latency

| Scope / runtime / route / C | req/s median [min,max] | p50 ms median [min,max] | p99 ms median [min,max] | Peak total MiB | Measured sockets created / requests reused (each run) | Generator CPU cores / saturation suspected |
| --- | --- | --- | --- | --- | --- | --- |
| direct / node / login / 1 | 11.621 [11.621, 11.621] | 86.226 [86.226, 86.226] | 86.243 [86.243, 86.243] | 104.594 [104.594, 104.594] | 0 / 3 of 3 | 0.012 [0.012, 0.012] / no |
| direct / node / login-scrypt / 1 | 15.296 [15.296, 15.296] | 65.128 [65.128, 65.128] | 65.775 [65.775, 65.775] | 136.594 [136.594, 136.594] | 0 / 3 of 3 | 0.018 [0.018, 0.018] / no |
| direct / node / verify / 1 | 7675.113 [7675.113, 7675.113] | 0.116 [0.116, 0.116] | 0.240 [0.240, 0.240] | 121.203 [121.203, 121.203] | 0 / 3071 of 3071 | 0.502 [0.502, 0.502] / no |
| direct / node / verify / 8 | 21002.040 [21002.040, 21002.040] | 0.341 [0.341, 0.341] | 0.818 [0.818, 0.818] | 122.859 [122.859, 122.859] | 0 / 8406 of 8406 | 1.205 [1.205, 1.205] / YES |
| direct / node / verify / 64 | 23342.431 [23342.431, 23342.431] | 2.697 [2.697, 2.697] | 4.074 [4.074, 4.074] | 132.344 [132.344, 132.344] | 0 / 9381 of 9381 | 1.228 [1.228, 1.228] / YES |
| direct / node / search / 1 | 1554.714 [1554.714, 1554.714] | 0.613 [0.613, 0.613] | 0.837 [0.837, 0.837] | 129.609 [129.609, 129.609] | 0 / 622 of 622 | 0.221 [0.221, 0.221] / no |
| direct / node / search / 8 | 1934.326 [1934.326, 1934.326] | 3.711 [3.711, 3.711] | 7.753 [7.753, 7.753] | 131.563 [131.563, 131.563] | 0 / 782 of 782 | 0.199 [0.199, 0.199] / no |
| direct / node / search / 64 | 1966.357 [1966.357, 1966.357] | 31.595 [31.595, 31.595] | 63.111 [63.111, 63.111] | 148.156 [148.156, 148.156] | 0 / 856 of 856 | 0.236 [0.236, 0.236] / no |
| direct / node / markdown / 1 | 1954.552 [1954.552, 1954.552] | 0.452 [0.452, 0.452] | 1.103 [1.103, 1.103] | 117.672 [117.672, 117.672] | 0 / 782 of 782 | 0.237 [0.237, 0.237] / no |
| direct / node / markdown / 8 | 2906.931 [2906.931, 2906.931] | 2.392 [2.392, 2.392] | 5.106 [5.106, 5.106] | 119.203 [119.203, 119.203] | 0 / 1170 of 1170 | 0.310 [0.310, 0.310] / no |
| direct / node / markdown / 64 | 2939.071 [2939.071, 2939.071] | 21.371 [21.371, 21.371] | 42.174 [42.174, 42.174] | 127.719 [127.719, 127.719] | 0 / 1239 of 1239 | 0.306 [0.306, 0.306] / no |
| direct / node / feed / 1 | 1501.671 [1501.671, 1501.671] | 0.620 [0.620, 0.620] | 0.951 [0.951, 0.951] | 118.719 [118.719, 118.719] | 0 / 601 of 601 | 0.280 [0.280, 0.280] / no |
| direct / node / feed / 8 | 1980.277 [1980.277, 1980.277] | 3.552 [3.552, 3.552] | 7.651 [7.651, 7.651] | 128.109 [128.109, 128.109] | 0 / 800 of 800 | 0.254 [0.254, 0.254] / no |
| direct / node / feed / 64 | 2055.281 [2055.281, 2055.281] | 30.590 [30.590, 30.590] | 60.911 [60.911, 60.911] | 128.172 [128.172, 128.172] | 0 / 886 of 886 | 0.229 [0.229, 0.229] / no |
| direct / node / upload-integrity / 1 | 929.435 [929.435, 929.435] | 1.003 [1.003, 1.003] | 1.691 [1.691, 1.691] | 210.063 [210.063, 210.063] | 0 / 372 of 372 | 0.311 [0.311, 0.311] / no |
| direct / node / upload-integrity / 8 | 1142.093 [1142.093, 1142.093] | 6.448 [6.448, 6.448] | 13.836 [13.836, 13.836] | 292.047 [292.047, 292.047] | 0 / 464 of 464 | 0.327 [0.327, 0.327] / no |
| direct / node / upload-integrity / 64 | 1147.960 [1147.960, 1147.960] | 54.641 [54.641, 54.641] | 80.987 [80.987, 80.987] | 525.813 [525.813, 525.813] | 0 / 524 of 524 | 0.361 [0.361, 0.361] / no |
| direct / node / gzip-export / 1 | 304.261 [304.261, 304.261] | 3.006 [3.006, 3.006] | 3.561 [3.561, 3.561] | 126.891 [126.891, 126.891] | 0 / 122 of 122 | 0.311 [0.311, 0.311] / no |
| direct / node / gzip-export / 8 | 420.856 [420.856, 420.856] | 16.780 [16.780, 16.780] | 36.135 [36.135, 36.135] | 160.391 [160.391, 160.391] | 0 / 175 of 175 | 0.368 [0.368, 0.368] / no |
| direct / node / gzip-export / 64 | 434.500 [434.500, 434.500] | 143.329 [143.329, 143.329] | 251.044 [251.044, 251.044] | 159.438 [159.438, 159.438] | 0 / 237 of 237 | 0.372 [0.372, 0.372] / no |
| direct / node / revenue / 1 | 430.911 [430.911, 430.911] | 2.248 [2.248, 2.248] | 2.793 [2.793, 2.793] | 113.234 [113.234, 113.234] | 0 / 173 of 173 | 0.161 [0.161, 0.161] / no |
| direct / node / revenue / 8 | 508.328 [508.328, 508.328] | 13.526 [13.526, 13.526] | 29.283 [29.283, 29.283] | 142.344 [142.344, 142.344] | 0 / 211 of 211 | 0.146 [0.146, 0.146] / no |
| direct / node / revenue / 64 | 505.285 [505.285, 505.285] | 121.886 [121.886, 121.886] | 138.219 [138.219, 138.219] | 177.375 [177.375, 177.375] | 0 / 262 of 262 | 0.180 [0.180, 0.180] / no |
| direct / node / image-histogram / 1 | 891.046 [891.046, 891.046] | 1.050 [1.050, 1.050] | 1.761 [1.761, 1.761] | 215.375 [215.375, 215.375] | 0 / 357 of 357 | 0.322 [0.322, 0.322] / no |
| direct / node / image-histogram / 8 | 1154.335 [1154.335, 1154.335] | 6.404 [6.404, 6.404] | 13.638 [13.638, 13.638] | 298.813 [298.813, 298.813] | 0 / 469 of 469 | 0.350 [0.350, 0.350] / no |
| direct / node / image-histogram / 64 | 1119.254 [1119.254, 1119.254] | 55.562 [55.562, 55.562] | 86.729 [86.729, 86.729] | 518.297 [518.297, 518.297] | 0 / 509 of 509 | 0.362 [0.362, 0.362] / no |
| direct / node / nearby-stores / 1 | 1030.800 [1030.800, 1030.800] | 0.937 [0.937, 0.937] | 1.221 [1.221, 1.221] | 123.391 [123.391, 123.391] | 0 / 413 of 413 | 0.199 [0.199, 0.199] / no |
| direct / node / nearby-stores / 8 | 1260.308 [1260.308, 1260.308] | 5.541 [5.541, 5.541] | 11.558 [11.558, 11.558] | 123.969 [123.969, 123.969] | 0 / 511 of 511 | 0.215 [0.215, 0.215] / no |
| direct / node / nearby-stores / 64 | 1291.233 [1291.233, 1291.233] | 48.544 [48.544, 48.544] | 96.724 [96.724, 96.724] | 125.406 [125.406, 125.406] | 0 / 581 of 581 | 0.192 [0.192, 0.192] / no |
| direct / node / hello / 1 | 12840.114 [12840.114, 12840.114] | 0.065 [0.065, 0.065] | 0.164 [0.164, 0.164] | 120.172 [120.172, 120.172] | 0 / 5137 of 5137 | 0.675 [0.675, 0.675] / no |
| direct / node / hello / 8 | 29015.056 [29015.056, 29015.056] | 0.221 [0.221, 0.221] | 0.701 [0.701, 0.701] | 120.641 [120.641, 120.641] | 0 / 11610 of 11610 | 1.419 [1.419, 1.419] / YES |
| direct / node / hello / 64 | 30785.058 [30785.058, 30785.058] | 1.976 [1.976, 1.976] | 3.960 [3.960, 3.960] | 121.438 [121.438, 121.438] | 0 / 12341 of 12341 | 1.422 [1.422, 1.422] / YES |
| direct / node / primes / 1 | 288.328 [288.328, 288.328] | 3.348 [3.348, 3.348] | 7.454 [7.454, 7.454] | 160.469 [160.469, 160.469] | 0 / 116 of 116 | 0.098 [0.098, 0.098] / no |
| direct / node / primes / 8 | 316.279 [316.279, 316.279] | 21.436 [21.436, 21.436] | 49.446 [49.446, 49.446] | 196.625 [196.625, 196.625] | 0 / 134 of 134 | 0.098 [0.098, 0.098] / no |
| direct / node / primes / 64 | 325.455 [325.455, 325.455] | 191.902 [191.902, 191.902] | 384.062 [384.062, 384.062] | 209.844 [209.844, 209.844] | 0 / 193 of 193 | 0.089 [0.089, 0.089] / no |
| direct / native / login / 1 | 0.108 [0.108, 0.108] | 8051.492 [8051.492, 8051.492] | 12272.679 [12272.679, 12272.679] | 5.250 [5.250, 5.250] | 0 / 3 of 3 | 0.000 [0.000, 0.000] / no |
| direct / native / login-scrypt / 1 | 11.988 [11.988, 11.988] | 82.939 [82.939, 82.939] | 84.572 [84.572, 84.572] | 37.109 [37.109, 37.109] | 0 / 3 of 3 | 0.016 [0.016, 0.016] / no |
| direct / native / verify / 1 | 10024.514 [10024.514, 10024.514] | 0.087 [0.087, 0.087] | 0.164 [0.164, 0.164] | 5.219 [5.219, 5.219] | 0 / 4010 of 4010 | 0.585 [0.585, 0.585] / no |
| direct / native / verify / 8 | 23569.424 [23569.424, 23569.424] | 0.342 [0.342, 0.342] | 0.646 [0.646, 0.646] | 5.813 [5.813, 5.813] | 0 / 9433 of 9433 | 1.228 [1.228, 1.228] / YES |
| direct / native / verify / 64 | 16929.384 [16929.384, 16929.384] | 3.304 [3.304, 3.304] | 7.264 [7.264, 7.264] | 8.672 [8.672, 8.672] | 0 / 6840 of 6840 | 1.097 [1.097, 1.097] / YES |
| direct / native / search / 1 | 115.563 [115.563, 115.563] | 7.978 [7.978, 7.978] | 20.795 [20.795, 20.795] | 29.594 [29.594, 29.594] | 0 / 47 of 47 | 0.087 [0.087, 0.087] / no |
| direct / native / search / 8 | 248.785 [248.785, 248.785] | 33.488 [33.488, 33.488] | 44.605 [44.605, 44.605] | 29.672 [29.672, 29.672] | 0 / 106 of 106 | 0.106 [0.106, 0.106] / no |
| direct / native / search / 64 | 418.288 [418.288, 418.288] | 132.948 [132.948, 132.948] | 186.741 [186.741, 186.741] | 30.625 [30.625, 30.625] | 0 / 195 of 195 | 0.070 [0.070, 0.070] / no |
| direct / native / markdown / 1 | 54.562 [54.562, 54.562] | 18.247 [18.247, 18.247] | 18.878 [18.878, 18.878] | 9.922 [9.922, 9.922] | 0 / 22 of 22 | 0.028 [0.028, 0.028] / no |
| direct / native / markdown / 8 | 54.731 [54.731, 54.731] | 146.300 [146.300, 146.300] | 147.109 [147.109, 147.109] | 10.156 [10.156, 10.156] | 0 / 26 of 26 | 0.017 [0.017, 0.017] / no |
| direct / native / markdown / 64 | 34.733 [34.733, 34.733] | 1852.503 [1852.503, 1852.503] | 1862.535 [1862.535, 1862.535] | 12.641 [12.641, 12.641] | 0 / 66 of 66 | 0.009 [0.009, 0.009] / no |
| direct / native / feed / 1 | 19.578 [19.578, 19.578] | 44.083 [44.083, 44.083] | 85.351 [85.351, 85.351] | 9.156 [9.156, 9.156] | 0 / 8 of 8 | 0.031 [0.031, 0.031] / no |
| direct / native / feed / 8 | 19.162 [19.162, 19.162] | 401.660 [401.660, 401.660] | 433.828 [433.828, 433.828] | 10.313 [10.313, 10.313] | 0 / 9 of 9 | 0.010 [0.010, 0.010] / no |
| direct / native / feed / 64 | 36.011 [36.011, 36.011] | 1776.607 [1776.607, 1776.607] | 1777.666 [1777.666, 1777.666] | 13.500 [13.500, 13.500] | 0 / 65 of 65 | 0.011 [0.011, 0.011] / no |
| direct / native / upload-integrity / 1 | 199.273 [199.273, 199.273] | 4.601 [4.601, 4.601] | 9.291 [9.291, 9.291] | 13.313 [13.313, 13.313] | 0 / 80 of 80 | 0.113 [0.113, 0.113] / no |
| direct / native / upload-integrity / 8 | 221.331 [221.331, 221.331] | 34.789 [34.789, 34.789] | 45.230 [45.230, 45.230] | 35.266 [35.266, 35.266] | 0 / 95 of 95 | 0.104 [0.104, 0.104] / no |
| direct / native / upload-integrity / 64 | 222.783 [222.783, 222.783] | 287.921 [287.921, 287.921] | 295.221 [295.221, 295.221] | 170.063 [170.063, 170.063] | 0 / 129 of 129 | 0.067 [0.067, 0.067] / no |
| direct / native / gzip-export / 1 | 369.380 [369.380, 369.380] | 2.180 [2.180, 2.180] | 4.069 [4.069, 4.069] | 8.844 [8.844, 8.844] | 0 / 148 of 148 | 0.369 [0.369, 0.369] / no |
| direct / native / gzip-export / 8 | 655.470 [655.470, 655.470] | 11.868 [11.868, 11.868] | 14.955 [14.955, 14.955] | 10.281 [10.281, 10.281] | 0 / 267 of 267 | 0.494 [0.494, 0.494] / no |
| direct / native / gzip-export / 64 | 643.901 [643.901, 643.901] | 96.215 [96.215, 96.215] | 126.785 [126.785, 126.785] | 17.672 [17.672, 17.672] | 0 / 291 of 291 | 0.441 [0.441, 0.441] / no |
| direct / native / revenue / 1 | 608.149 [608.149, 608.149] | 1.573 [1.573, 1.573] | 2.196 [2.196, 2.196] | 5.922 [5.922, 5.922] | 0 / 244 of 244 | 0.265 [0.265, 0.265] / no |
| direct / native / revenue / 8 | 1265.203 [1265.203, 1265.203] | 6.252 [6.252, 6.252] | 8.001 [8.001, 8.001] | 6.641 [6.641, 6.641] | 0 / 513 of 513 | 0.238 [0.238, 0.238] / no |
| direct / native / revenue / 64 | 1338.128 [1338.128, 1338.128] | 47.572 [47.572, 47.572] | 52.830 [52.830, 52.830] | 12.047 [12.047, 12.047] | 0 / 599 of 599 | 0.254 [0.254, 0.254] / no |
| direct / native / image-histogram / 1 | 661.626 [661.626, 661.626] | 1.460 [1.460, 1.460] | 1.874 [1.874, 1.874] | 13.672 [13.672, 13.672] | 0 / 265 of 265 | 0.234 [0.234, 0.234] / no |
| direct / native / image-histogram / 8 | 792.316 [792.316, 792.316] | 10.061 [10.061, 10.061] | 11.193 [11.193, 11.193] | 40.156 [40.156, 40.156] | 0 / 321 of 321 | 0.271 [0.271, 0.271] / no |
| direct / native / image-histogram / 64 | 769.507 [769.507, 769.507] | 81.375 [81.375, 81.375] | 99.613 [99.613, 99.613] | 205.891 [205.891, 205.891] | 0 / 349 of 349 | 0.248 [0.248, 0.248] / no |
| direct / native / nearby-stores / 1 | 834.123 [834.123, 834.123] | 1.102 [1.102, 1.102] | 2.269 [2.269, 2.269] | 5.484 [5.484, 5.484] | 0 / 334 of 334 | 0.214 [0.214, 0.214] / no |
| direct / native / nearby-stores / 8 | 1091.416 [1091.416, 1091.416] | 7.295 [7.295, 7.295] | 7.963 [7.963, 7.963] | 5.563 [5.563, 5.563] | 0 / 442 of 442 | 0.194 [0.194, 0.194] / no |
| direct / native / nearby-stores / 64 | 1100.348 [1100.348, 1100.348] | 57.644 [57.644, 57.644] | 62.117 [62.117, 62.117] | 6.563 [6.563, 6.563] | 0 / 493 of 493 | 0.160 [0.160, 0.160] / no |
| direct / native / hello / 1 | 14239.944 [14239.944, 14239.944] | 0.058 [0.058, 0.058] | 0.159 [0.159, 0.159] | 3.438 [3.438, 3.438] | 0 / 5697 of 5697 | 0.786 [0.786, 0.786] / no |
| direct / native / hello / 8 | 30969.261 [30969.261, 30969.261] | 0.213 [0.213, 0.213] | 0.579 [0.579, 0.579] | 3.531 [3.531, 3.531] | 0 / 12391 of 12391 | 1.388 [1.388, 1.388] / YES |
| direct / native / hello / 64 | 30565.300 [30565.300, 30565.300] | 1.947 [1.947, 1.947] | 4.100 [4.100, 4.100] | 4.281 [4.281, 4.281] | 0 / 12252 of 12252 | 1.409 [1.409, 1.409] / YES |
| direct / native / primes / 1 | 255.924 [255.924, 255.924] | 3.693 [3.693, 3.693] | 5.167 [5.167, 5.167] | 6.469 [6.469, 6.469] | 0 / 103 of 103 | 0.111 [0.111, 0.111] / no |
| direct / native / primes / 8 | 305.342 [305.342, 305.342] | 26.164 [26.164, 26.164] | 26.832 [26.832, 26.832] | 6.063 [6.063, 6.063] | 0 / 130 of 130 | 0.074 [0.074, 0.074] / no |
| direct / native / primes / 64 | 303.753 [303.753, 303.753] | 210.909 [210.909, 210.909] | 213.835 [213.835, 213.835] | 6.891 [6.891, 6.891] | 0 / 131 of 131 | 0.046 [0.046, 0.046] / no |

## Observed native proxy/topology cost

| Route / C | Δ median p50 ms | Δ median p99 ms | end-to-end/direct req/s | Client saturation suspected |
| --- | --- | --- | --- | --- |


## Event-loop isolation (each repetition)

| Runtime / window / repeat | Light group relation | Probe | Requests | p50 ms | p99 ms | Heavy completed |
| --- | --- | --- | --- | --- | --- | --- |


## Synthetic threads: sharing ergonomics and overhead

| Variant / workers | Internal ms median [min,max] | Warmed total RSS MiB median [min,max] |
| --- | --- | --- |


Same-process net RSS growth from 1 to 4 warmed workers; not allocation size. See the threads definition.

| Variant | 1-worker RSS MiB | 4-worker RSS MiB | Marginal warmed RSS / added worker MiB |
| --- | --- | --- | --- |


## Precise metric definitions

- **cold-start:** Monotonic wall time immediately before spawn to the first HTTP response with expected status and fully drained body. Fresh process each sample; readiness retries every 2 ms. Direct uses the exact generated .next/scriptc/entry-N.ts under Node 24 type stripping versus its compiled binary; no Next. End-to-end includes next start (Node) or the recorded native production command and the first execution of the specified route. OS filesystem caches are not flushed; this is process-cold, not machine-cold. Median averages the middle two values for even N; p90 uses nearest rank.
- **memory-idle:** RSS after first successful readiness request and the configured quiet interval. Includes initialization by that route, not an untouched process. Direct: route process. End-to-end: entire owned process tree, including Next, adapter supervisor, all native binaries and descendants. Linux uses the kernel's approximate stat RSS counter; macOS uses ps RSS. Totals sum resident mappings and may double-count shared OS/library pages; not PSS or unique physical memory.
- **cpu-fixed-count:** After untimed warmup, user+system CPU delta of the stable owned process tree over exactly N successful sequential keep-alive requests, divided by N. Linux /proc/PID/stat excludes child CPU fields to avoid double counting; Node worker threads are already in process totals. macOS ps TIME is rounded to centiseconds. The generator warms its own process and keep-alive agent before an IPC barrier; CPU snapshots bracket release through generator shutdown, excluding spawn/warmup. Boundary sampling and idle runtime CPU remain; generator CPU is excluded and reported separately. Each row carries before/after per-process CPU and RSS. N is per repetition, after prior warmup; RSS after N is not a fresh-process measurement.
- **throughput-latency:** Separate-process HTTP/1.1 keep-alive closed-loop generator with C outstanding requests, no pipelining; dispatch until duration expires, then drain all in-flight requests. Throughput = completed responses / actual dispatch-to-final-drain seconds. Latency = dispatch to fully drained body; nearest-rank p50/p99 within a run. No coordinated-omission correction; this measures closed-loop capacity, not an external arrival-rate SLA. Each sample warms the same generator process and agent at its C before the IPC start barrier. Socket creations and reused requests are counted separately for warmup and measurement; repeats retained independently, with median and min/max across runs.
- **peak-rss:** Largest sampled simultaneous sum of process-tree RSS, sampled every 100 ms plus the before/after boundaries. Sampler reads only the previously discovered tree (targeted ps on macOS, /proc on Linux); full discovery at both boundaries checks stable process membership. Each peak snapshot contains every process. This is a lower bound on peak RSS, not a kernel high-water mark. On a loaded host ps/scheduling can lengthen the interval.
- **hop-cost:** Native end-to-end minus native direct median p50/p99 at identical concurrency, input and affinity. Also report end-to-end/direct throughput ratio. This is an observed topology difference including Next routing/proxy/serialization/scheduling, not a pure network-hop stopwatch. The samples are separate runs; percentile differences are not percentiles of paired hop times and may be negative under noise.
- **isolation:** First warm heavy and probe endpoints. Baseline and loaded windows each dispatch one sequential probe per path, in parallel, waiting 20 ms after completion. Loaded window additionally holds one heavy request outstanding, back to back. Record probe p50/p99 and sample counts alongside completed heavy requests; equal offered concurrency, not equal achieved heavy RPS. Heavy load starts 100 ms before probes; drain is included. A synchronous Node handler may delay even accepting probes. Requests cannot be preempted at the deadline.
- **threads:** One million orders, 8 regions, 12 scenarios, 60 months; exact integer-cent totals compared across all variants/counts. Fresh process per variant, growing its retained pool through 1/2/4 workers. One readiness computation at 1 worker, then two full warmups at each count before repeated internal dispatch+compute+reduction timings. Counts run ascending and share JIT/GC history. Dataset/pool setup and HTTP excluded. RSS includes the dataset and all worker threads. Marginal warmed RSS/added worker = (median post-job RSS at 4 workers - median post-job RSS at 1 worker) / 3 within that SAME process. The instantaneous dataset-construction RSS is no longer the baseline; this measures net resident growth including GC/JIT/allocator history, not exact clone allocations. Negative values, if any, remain visible as GC/noise and do not mean negative worker allocation. SAB uses four hand-filled Int32 SharedArrayBuffers; object variants share the original route and worker source. Node object workers clone workerData; native publishes ordinary object graphs. No forced GC.

## Failure (partial data; do not publish)

```
Error: connect ECONNREFUSED 127.0.0.1:3417
    at TCPConnectWrap.afterConnect [as oncomplete] (node:net:2083:16)
```
